package A;
public class Main{
	public Main(){}
	public a m(){}	//should link to a
}
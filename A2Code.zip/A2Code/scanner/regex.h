#ifndef __REGEX_H__
#define __REGEX_H__

#include "NFA.h"
#include <string>
#include <vector>
#include <stdio.h>
#include <iostream>
using namespace std;
/*
Regular expression rule
R->R|R|R...
R->TERMINAL
R->TERMINAL+R
R->R*
TERMINAL = string or [a-b]
*/
enum Rule
{
	STAR,
	UNION,
	TERMINAL,
	MULTIPLEOR
};
class RegEx
{
	private:
	int isTerminal;
	vector<string> exps;
	Rule rule;
	string type;
	int isComment;
	public:
	void changeisComment();
	RegEx(string type, string exp);
	vector<string> getexps();
	Rule getrule();
	NFA convertToNFA();
};
	

#endif

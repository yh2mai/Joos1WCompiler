public abstract final class Je_abstract_final_class{	//should output 42
	public static int test(){}
}
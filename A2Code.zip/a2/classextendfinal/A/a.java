package A;
public final class a{
	public a(){}
}
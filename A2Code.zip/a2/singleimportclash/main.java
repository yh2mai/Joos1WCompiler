import A.main;
public class main{	//No single-type-import declaration clashes with the class declared in the same file.
	main(){}
}
package A;
public class main{
	main(){}
}
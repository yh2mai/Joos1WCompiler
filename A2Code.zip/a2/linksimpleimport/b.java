package B;
public class b{
	public b(){}
}
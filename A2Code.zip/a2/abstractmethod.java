public class abstractmethod{
	public abstractmethod(){}
	public abstract int m();
}
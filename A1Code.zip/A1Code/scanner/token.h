#ifndef __TOKEN_H__
#define __TOKEN_H__
#include <string>

struct Token{
  std::string kind;
  std::string lexeme;
  int i;
  Token(){}
  Token(std::string k, std::string l);
  // might need more to store double, long...
};

#endif

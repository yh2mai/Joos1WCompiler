public interface staticmethod_interface{
	final int m();	//An interface method cannot be static, final, or native
}
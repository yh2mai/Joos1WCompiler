#include <iostream>
#include <fstream>
#include <string>
#include <iterator>
#include <vector>
#include <algorithm>
#include "scanner/DFA.h"
#include "scanner/token.h"
#include "scanner/tokenizer.h"
#include "parser/lr1.h"
#include "parser/parsetree.h"
#include "parser/weeder.h"
#define DEBUG_PARSE false

using namespace std;

/*helper function to get the file info
vector<string> routeandname("stdlib/2.0/java/lang/String.java")-> ("stdlib/2.0/java/lang/String.java","stdlib", "2.0", "java", "lang", "String.java","String")
*/
vector<string> routeandname(string javafile)
{
	vector<string> temp;
	temp.push_back(javafile);
	string name;
	while(javafile != "")
	{
		if(javafile.substr(0,1) != "/")
		{
			name = name + javafile.substr(0,1);
			javafile.erase(javafile.begin());
		}
		else
		{
			javafile.erase(javafile.begin());
			temp.push_back(name);
			name = "";
		}
	}
	temp.push_back(name);
	temp.push_back(name.substr(0, name.length() - 5));
	return temp;
}
//end routeandname

int main (int argc, char* argv[])
{
	if (argc == 1) {
		cout << "Usage: ./scan filename" << endl;
		return 0;
	}
	DFA dfa("scanner/dfa");
	LR1 lr1("parser/joosc.lr1");
	for(int i =1; i< argc; i++)
	{
		string javafile = argv[i];
		string all = "";
		string line;
		vector<string> route_name = routeandname(javafile);
		ifstream myfile (javafile);
		if (myfile.is_open())
		{
				while ( myfile.good() )
				{
						getline (myfile,line);
			all = all + line + "\n";
				}
				myfile.close();
		}
		else {
		cerr << "Unable to open file " << javafile << endl; 
		exit(1);
		}
		int invalidtokenizer = 0;
		vector<struct Token> tokens = tokenizer(dfa, all,&invalidtokenizer);
		if(invalidtokenizer)
		{
			return 42;
		}
		int result = lr1.parse(tokens); 
		if(result)
		{
		if(DEBUG_PARSE)	cerr << "CAN NOT PARSE" << endl;
			return 42;
		}
		vector<struct exrule> Derivation;
		Derivation = lr1.derivations;
		parsetree *tree= new parsetree(lr1,&Derivation, "CompilationUnit",&tokens);
		parsetree * AST = ast(tree);
		if(!inRange(getnumber(AST)))
		{
		if(DEBUG_PARSE) cerr << "NUMBER IS OUT OF RANGE." << endl;
		return 42;
		}
		if(weeder(AST)  || weeder_name(AST,route_name.at(route_name.size() - 1)))
		{
		if(DEBUG_PARSE) cerr << "WEEDER FOUND SOMETHING WRONG." << endl;
		return 42;
		}
		if(DEBUG_PARSE) AST->print(0);
	}
	return 0;
}

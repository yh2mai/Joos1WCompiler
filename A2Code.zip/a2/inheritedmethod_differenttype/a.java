package A;
public class a{
	public a(){}
	public char m(int a,char b){}
}
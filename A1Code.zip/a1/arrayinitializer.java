public class arrayinitializer{
	public int[] a = new int[10];
}
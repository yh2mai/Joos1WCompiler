public class fieldaccess{
	public int f = 1;
	public static int test(){
	int d = fieldaccess.f;
	}
}
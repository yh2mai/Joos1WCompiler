#include <iostream>
#include <fstream>
#include <string>
#include <iterator>
#include <vector>
#include <algorithm>
#include "scanner/DFA.h"
#include "scanner/token.h"
#include "scanner/tokenizer.h"
#include "parser/lr1.h"
#include "parser/parsetree.h"
#include "parser/weeder.h"
#include "environment/scope.h"
#include "nameresolution/link_type.h"
#include "environment/hierarchycheck.h"
#define DEBUG_PARSE false
#define DEBUG_SCOPE false
#define writestd false
#define DEBUG_LINK false

using namespace std;

vector<parsetree*> stdlibpts;
/*helper function to get the file info
vector<string> routeandname("stdlib/2.0/java/lang/String.java")-> ("stdlib/2.0/java/lang/String.java","stdlib", "2.0", "java", "lang", "String.java","String")
*/
vector<string> routeandname(string javafile)
{
	vector<string> temp;
	temp.push_back(javafile);
	string name;
	while(javafile != "")
	{
		if(javafile.substr(0,1) != "/")
		{
			name = name + javafile.substr(0,1);
			javafile.erase(javafile.begin());
		}
		else
		{
			javafile.erase(javafile.begin());
			temp.push_back(name);
			name = "";
		}
	}
	temp.push_back(name);
	temp.push_back(name.substr(0, name.length() - 5));
	return temp;
}
//end routeandname

vector<parsetree*> pts;

int main (int argc, char* argv[])
{
	vector<string> std = stdlibs();
	if (argc == 1) {
		cout << "Usage: ./scan filename" << endl;
		return 0;
	}
	DFA dfa("scanner/dfa");
	LR1 lr1("parser/joosc.lr1");
	vector<string> javafiles;
	for(int i =1; i< argc; i++)
	{
		string javafile = argv[i];
		if(is_member(javafile,javafiles))
		{
			if(DEBUG_SCOPE) cerr << "No two classes or interfaces have the same canonical name." << endl;
			return 42;
		}
		else
		{
			javafiles.push_back(javafile);
		}
		string all = "";
		string line;
		vector<string> route_name = routeandname(javafile);
		parsetree * AST;
		if(is_member("stdlib",route_name))
		{
			if(writestd)
			{
				string filepath = javafile;
				string all = "";
				string line;
		
				ifstream myfile (javafile);
				if (myfile.is_open())
				{
					while ( myfile.good() )
					{
						getline (myfile,line);
						all = all + line + "\n";
					}
				myfile.close();
				}

				else {cout << "Unable to open file " << javafile << endl; 
				return 1;
					}
				int invalidtokenizer = 0;
				vector<struct Token> tokens = tokenizer(dfa, all,&invalidtokenizer);
				lr1.parse(tokens);
				vector<struct exrule> Derivation;
				Derivation = lr1.derivations;
				parsetree *tree = new parsetree(lr1,&Derivation, "CompilationUnit",&tokens);
				AST = ast(tree);
				string classname = route_name.at(route_name.size() - 1);
				ofstream *o = new ofstream("std/" + classname +".ast");
				AST->write(o);
				if(DEBUG_PARSE)
					AST->print(0);
			}
			else
			{
				string classname = route_name.at(route_name.size()-1);
				ifstream * f = new ifstream("std/" + classname + ".ast");
				AST = new parsetree(f);
				stdlibpts.push_back(AST);
				f->close();
			}
		}
		else
		{
			ifstream myfile (javafile);
			if (myfile.is_open())
			{
					while ( myfile.good() )
					{
							getline (myfile,line);
				all = all + line + "\n";
					}
					myfile.close();
			}
			else {
			cerr << "Unable to open file " << javafile << endl; 
			exit(1);
			}
			int invalidtokenizer = 0;
			vector<struct Token> tokens = tokenizer(dfa, all,&invalidtokenizer);
			if(invalidtokenizer)
			{
				return 42;
			}
			int result = lr1.parse(tokens); 
			if(result)
			{
			if(DEBUG_PARSE)	cerr << "CAN NOT PARSE" << endl;
				return 42;
			}
			vector<struct exrule> Derivation;
			Derivation = lr1.derivations;
			parsetree *tree= new parsetree(lr1,&Derivation, "CompilationUnit",&tokens);
			AST = ast(tree);
		}
		if(!inRange(getnumber(AST)))
		{
		if(DEBUG_PARSE) cerr << "NUMBER IS OUT OF RANGE." << endl;
		return 42;
		}
		if(weeder(AST)  || weeder_name(AST,route_name.at(route_name.size() - 1)))
		{
		if(DEBUG_PARSE) cerr << "WEEDER FOUND SOMETHING WRONG." << endl;
		return 42;
		}
		if(DEBUG_PARSE && !is_member(route_name.at(route_name.size() - 1), std)) AST->print(0);
		mark_scope_buildenv(AST);
		if(AST->getscope()->package!= NULL)
		{
			parsetree* package = AST->getscope()->package->at(1);
			while(package->getname() != "ID")
				package = package->at(0);
			if(package->getlexeme() == "java" && package->getparent()->at(2)->getlexeme() == "lang" &&!is_member(scopetoclass_interfacename(AST->getscope()), std))
			{
				stdlibpts.push_back(AST);
			}
		}
		if(DEBUG_SCOPE) 
		{
			if(!is_member(scopetoclass_interfacename(AST->getscope()), std))
			{
			AST->print(0);
			AST->getscope()->print(0);
			}
		}
		pts.push_back(AST);
	}
	for(int i = 0 ; i < pts.size(); i++)
	{
		link_type(pts.at(i));
		if(DEBUG_LINK && !is_member(scopetoclass_interfacename(pts.at(i)->getscope()), std)) 
		{
			pts.at(i)->print(0);
			pts.at(i)->getscope()->print(0);
		}
	}
	for(int i =0; i < pts.size(); i++)
	{
		hierarchycheck(pts.at(i)->getscope());
	}
	return 0;
}

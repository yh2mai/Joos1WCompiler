package a;
public class A{
	A(){}
}
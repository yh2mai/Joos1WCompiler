public class link_encloseclass{
	public link_encloseclass(){}
	public link_encloseclass m(){}	//should link to link_encloseclass
}
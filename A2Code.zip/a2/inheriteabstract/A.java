package B;
public class A extends b{		//b has abstract method
	public A(){}
}
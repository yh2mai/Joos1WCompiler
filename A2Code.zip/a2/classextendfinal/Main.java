package A;
public class Main extends a{	//a is a final class
	public Main(){}
}
#ifndef __LR1_H__
#define __LR1_H__

#include <vector>
#include <string>
#include <map>

using namespace std;

vector<string> str_tokenize(string s);
vector<string> TokensToStrings(vector<struct Token>);

// input: a vector of tokens
// output: a vector of token kinds

void print_strings(vector<string> s);
void print_ints(vector<int>);

enum rs{
	SHIFT, // 0
	REDUCED, // 1
	ERROR // 2
};

struct exrule {
	string from;
	vector<string> to;
	exrule(){}
	exrule(string f, vector<string> t);
	void print();
};


struct rsrule{			//reduced rule structure
	int from;			//From state
	string middle;		// token kind
	rs kind;			//Rule type
	int to;			//Rule or To state
    	rsrule(){}
    	rsrule(int f, string m, rs k, int t);
    	void print();
};


class LR1{
	private:
		// int num_terminal;   // Number of terminals
		// int num_n_terminal; // Number of non-terminals
		// int num_state;			//Number of state
		// int num_exrule; // number of expansion rule
		// int num_rsrule;		//Number of r_s_rule
		
		string start; // start symbol
		vector<string> terminals; //Terminals
		vector<string> n_terminals; //Non-Terminals
        	int num_state;		//Number of state
		vector<struct exrule> exrules;	//r_s_rules
		vector<struct rsrule> rsrules;	//r_s_rules
		
	
	public:
		map<string,int> terminals_hash;
		LR1(string filename);
		vector<struct exrule> derivations;
		void set_start(string);
		void add_terminal(string);
		void add_n_terminal(string);
		void add_rsrule(int f, string m, rs k, int t);
		void add_exrule(vector<string>);
		
		vector<string> getterminals();
		
		struct exrule get_ex(int);
		int parse(vector<struct Token> tokens); // returns the next state number. returns -1 if should reduce, -2 for error
		struct rsrule next(int, string); // returns the rule# or 2 if no rule can apply
		void print();
};

#endif

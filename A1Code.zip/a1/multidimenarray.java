public class multidimenarray{
	multidimenarray(){ int[][] a;}
}
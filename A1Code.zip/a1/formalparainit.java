public class formalparainit{
	public int m(int k = 0){}	//A formal parameter of a method must not have an initializer.
}
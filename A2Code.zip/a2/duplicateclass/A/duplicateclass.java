public class duplicateclass{
	duplicateclass(){}
}
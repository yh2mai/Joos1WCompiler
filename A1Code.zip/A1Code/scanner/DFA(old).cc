#include "DFA.h"
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include "hashtable.h"
#include "lr1.h"

using namespace std;

int StringToInt(string s) {
	return atoi(s.c_str());
}

DState::DState(int idd, string kinds, int is, vector<int> idds) {
	id = idd;
	kind = kinds;
	isTerminal = is;
	ids = idds;
}

DTransition::DTransition(DState f, DState tt, string m) {
	from = f;
	to = tt;
	t = m;
}

int member(string x, vector <string> list){
	int size = list.size();
	for (int i=0; i<size; i++){
		if (list.at(i) == x) {return 1;}
	}
	return 0;
}

vector<string> stringtovector(string s, vector<string> list){
	int size = s.length();
	for(int i = 0; i<size; i++){
		list.push_back(s.substr(i,1));
	}
	return list;
}


void print_dstate(DState s) {
	cout << "ID " << s.id << endl;
	cout << "Kind " << s.kind << endl;
	cout << "isTerminal " << s.isTerminal << endl;
	cout << "IDs ";
	for (int i = 0; i < s.ids.size(); i++) {
		cout << s.ids.at(i) << " ";
	}
	cout << endl;
}

void write_dstate(std::ofstream& f, DState s) {
	f << "ID " << s.id << endl;
	f << "Kind " << s.kind << endl;
	f << "isTerminal " << s.isTerminal << endl;
	f << "IDs ";
	for (int i = 0; i < s.ids.size(); i++) {
		f << s.ids.at(i) << " ";
	}
	f << endl;
}


DFA::DFA() {
	state_ctr = 0;
	start = 0;
	ttable = kind_priority_hash();
}

// read DFA from file
DFA::DFA(string file) {
	state_ctr = 0;
	start = 0;
	ttable = kind_priority_hash();
	
	string line;
  ifstream dfafile (file);
	if (!dfafile) {
		cout << "Unable to open file" << file << endl; 
		dfafile.close();
		exit(1);
	}

	else if( dfafile.is_open() ) {
		// debug
		// cout << "open success" << endl;
		char x;

		while(1) {
			string alpha;
			do {
				x = dfafile.get();

			} while (x != '$' && x != '\n');
			
			if (x == '\n') { break; }
			x = dfafile.get();
			
			while (x != '$') {
				// cout << "got " << x << endl;
				alpha += (string)&x;
				x = dfafile.get();
			} 

			alphs.push_back(alpha);
			alpha = "";
			// push the string to alphas
		
		}
		x = dfafile.get(); // newline char
		
		while (1) {
			string id, kind, terminal, ids, nothing;
			vector<string> idss;
			vector<int> idnum;
			
			
			getline(dfafile, id);
			if (id.length() < 1) {
				break;
			}
			getline(dfafile, kind);
			getline(dfafile, terminal);
			getline(dfafile, ids);
			
			
			idss = str_tokenize(ids);
			for (int i = 1; i < idss.size(); i++) {
				idnum.push_back(StringToInt(idss.at(i)));
			}
			idnum.resize(idnum.size()-1);
			
			int f_id = StringToInt(str_tokenize(id).at(1));
			int f_term = StringToInt(str_tokenize(terminal).at(1));
			string f_kind = str_tokenize(kind).at(1);
						
			struct DState d = DState(f_id, f_kind, f_term, idnum);
			// print_dstate(d);
			states.push_back(d);
			
			getline(dfafile, nothing);
			// make a new state, push state
		}
		
		while (1) {
			char a;
			string s1, s2;
			string line = "";
			
			dfafile >> s1;
			if (s1.length() < 1) {
				break;
			}
// cout << "s1[" << s1 << "]";
			dfafile.get();// space
			dfafile.get();// $
			
			a = dfafile.get();
			while (a != '$') {
// cout << "a[" << a << "] ";
				line += (string)&a;
				a = dfafile.get();
			} 
			
			dfafile.get();// space
			
			dfafile >> s2;
// cout << "s2[" << s2 << "]" << endl;
			dfafile.get();// newline
			
			int from, to;
			from = StringToInt(s1);
			to = StringToInt(s2);
			struct DTransition dt = DTransition(states.at(from), states.at(to), line);
			trans.push_back(dt);
			// cout << dt.from.id << "[" << dt.t << "]" << dt.to.id << endl;
			line = "";
			
			
			// save this to transition
		}
		
	}
	dfafile.close();
	
}

vector<string> DFA::get_alphas() {
	return alphs;
}

vector<struct DState> DFA::get_states() {
	return states;
}

vector<struct DTransition> DFA::get_trans() {
	return trans;
}
	

void DFA::set_alphas(vector<string> t) {
	alphs = t;
}

int DFA::get_ctr() {
  return state_ctr;
}

int DFA::is_terminal(int k) {
  return get_state(k).isTerminal;
}


void DFA::addState(struct DState s) {
  states.push_back(s);
  state_ctr += 1;
}

void DFA::addTrans(struct DState from , string a, struct DState to) {
  //Michael
  struct DTransition DTrans;
  DTrans.from = from;
  DTrans.t = a;
  DTrans.to = to;
  trans.push_back(DTrans);
}

struct DState DFA::get_state(int k) {
  return states.at(k);
}


void DFA::determineId(struct DState* s) {
  s->id = get_ctr();
}


void DFA::determineKind(NFA nfa, struct DState* s) {
  // TODO
  // need a priority list/hash table
  // use priority to determine the kind of s
// cout << "determineKind: The states contains the following kinds: " << endl;
string kind = nfa.get_state(s->ids.at(0)).kind;
string next = nfa.get_state(s->ids.at(0)).kind;
// cout << "determineKind: continue " << endl;

for (int i = 0; i < s->ids.size(); i++) {

	if (kind.length() < 1) {
		kind = nfa.get_state(s->ids.at(i)).kind;
		continue;
	}
	
	next = nfa.get_state(s->ids.at(i)).kind;
	if (next.length() > 0) {
		if (ttable[next] < ttable[kind]) {
			kind = next;
		}
		// cout << kind << "[" << ttable[kind] << "] ";
	}
}
// cout << endl;

s->kind = kind;
// cout << "kind is " << kind << endl;
}

void DFA::determineTerminal(NFA nfa, struct DState* s) {
	s->isTerminal = 0;	
  for (int i = 0; i < s->ids.size(); i++) {
    if (nfa.is_end(s->ids.at(i))) {
      s->isTerminal = 1;
			break;
    }
  }
}


int DFA::reach(int current, string a){
	int max = trans.size();
	vector<string> list;
	
	
	for (int i=0; i<max; i++) {
		if (current == trans.at(i).from.id){
			if (trans.at(i).t.size() == 1)
			{
				if(trans.at(i).t == a) 
				{
					return trans.at(i).to.id;
				}
			}
			else
			{
				string k = trans.at(i).t.substr(1);
				int isIn = 0;
				for(int j = 0 ; j < k.size(); j++)
				{
					if(k.substr(j,1) == a)
						isIn = 1;
				}
				if(!isIn)
					return trans.at(i).to.id;
			}
		}
	}
	//cannot reach any valid state.
	return -1;
}

void print_ids(struct DState s) {
	for (int i = 0; i< s.ids.size(); i++) {
		cout << s.ids.at(i) << " ";
	}
	cout << endl;
}

int DFA::has_state(struct DState* s) {
  // returns 0 if DFA does not have state s
  // this function run time is about DFA.state.size() * s.ids.size()
  // which is big
	vector<int>::iterator it;
	
// cout << "has_state: DState initially has ids: ";
// print_ids(*s);

	sort (s->ids.begin(), s->ids.end());
// cout << "has_state: after sort ids: ";
// print_ids(*s);

  it = unique(s->ids.begin(), s->ids.end());
	s->ids.resize(it - s->ids.begin());
  // unique removes the consecutive duplicate  elements from the range [first,last). 

// cout << "has_state: after unique ids: ";
// print_ids(*s);
  
  for (int i = 0; i < states.size(); i++) {
    int j;
    
    if (states.at(i).ids.size() != s->ids.size()) {
      continue;
    }
    
    for (j = 0; j < states.at(i).ids.size(); j++) {
      if (s->ids.at(j) != states.at(i).ids.at(j)) {
        break;
      }
    }
    if ( j == states.at(i).ids.size()) {
      // cout << "combined state already exists" << endl;
			s->id = states.at(i).id;
      return 1;
    }
  }
  return 0;
}



void DFA::write_dfa(string filename) {
	// write dfa to file
	vector<string> a = alphs;
	vector<struct DState> s = states;
	vector<struct DTransition> t = trans;
	
	ofstream myfile;
  myfile.open (filename);
	
	
	for (int i = 0; i < a.size(); i++) {
		myfile << "$" << a.at(i) << "$ ";
	}
	
	myfile << endl;
	myfile << endl;
	
	for (int i = 0; i < s.size(); i++) {
		write_dstate(myfile, s.at(i));
		myfile << endl;
	}
	myfile << endl;
	
	
	for (int i = 0; i < t.size(); i++) {
		myfile << t.at(i).from.id << " $" << t.at(i).t << "$ " << t.at(i).to.id << endl;
	}
	myfile.close();
}

void DFA::print_dfa() {
cout << "===DFA INFO===" << endl;
	vector<string> a = alphs;
	vector<struct DState> s = states;
	vector<struct DTransition> t = trans;

	for (int i = 0; i < a.size(); i++) {
		cout << "$" << a.at(i) << "$ ";
	}
	
	cout << endl;
	cout << endl;
	
	for (int i = 0; i < s.size(); i++) {
		print_dstate(s.at(i));
		cout << endl;
	}
	cout << endl;
	
	
	for (int i = 0; i < t.size(); i++) {
		cout << t.at(i).from.id << " $" << t.at(i).t << "$ " << t.at(i).to.id << endl;
	}
}





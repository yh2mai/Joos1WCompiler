#ifndef __SCOPE_H__
#define __SCOPE_H__
#include "../parser/parsetree.h"
#include <vector>
#include <string>

class scope{
	private:
		vector<scope*> children;
		string name;
		scope* parent;
	public:
		scope();
		void addchild(scope* s);
		string getname();
		parsetree* package;
		vector<parsetree*> singleimports;
		vector<parsetree*> ondemandimports;
		vector<parsetree*> classes;
		vector<parsetree*> interfaces;
		vector<parsetree*> methods;
		vector<parsetree*> fields;
		vector<parsetree*> vars;
		vector<parsetree*> cons;
		scope* getparent();
		void setparent(scope* s);
		scope(string name);
		scope* at(int i);
		int size();
		void print(int i);
};
void mark_scope_buildenv(parsetree* pt);
string classname(parsetree* pt);
string interfacename(parsetree* pt);
string fieldname(parsetree* pt);
string varname(parsetree* pt);
int class_clash_singleimport(parsetree* pt);
string singleimportclassname(parsetree* pt);
int interface_clash_singleimport(parsetree* pt);
int singleimport_clash_eachother(parsetree* pt);
int samepackage(parsetree* pt, parsetree* pt2);
parsetree* singleimporttoclass(parsetree* pt);
vector<parsetree*> matchclasses_ondemand(parsetree* pt, string classname);
int packagematch(parsetree* pt1, parsetree* pt2);
string scopetoclass_interfacename(scope* s);
int scopeisclass(scope* s);
int duplicatemethod(parsetree* pt, scope* s);
string getmethodname(parsetree* pt);
int sameparameters(parsetree* pt1, parsetree* pt2);
parsetree* getpara_tree(parsetree* pt);
int sametype(parsetree* pt1, parsetree* pt2);
int duplicatecons(parsetree* pt, scope* s);
parsetree* objectclass();
int class_clash_eachother(parsetree* pt);
#endif
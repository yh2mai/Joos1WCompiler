public class finalfield{
	public finalfield(){}
	final int i = 0;
}
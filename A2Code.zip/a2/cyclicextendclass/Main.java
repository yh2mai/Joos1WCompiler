package A;
public class Main extends A
{
	public Main(){}
}
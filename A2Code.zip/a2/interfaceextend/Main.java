import A.*;
public interface Main extends a, b	//a is a class
{
	
}
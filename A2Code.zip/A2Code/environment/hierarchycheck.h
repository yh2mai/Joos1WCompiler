#ifndef __HIERARCHYCHECK_H__
#define __HIERARCHYCHECK_H__
#include "../parser/parsetree.h"
#include "scope.h"
#include <vector>
#include <string>
int hierarchycheck(scope* s);
parsetree* superclass(parsetree* pt);
vector<parsetree*> implementinterfaces(parsetree* pt);
vector<parsetree*> superclassesandinterfaces(parsetree* pt);
vector<parsetree*> superinterfaces(parsetree* pt);
vector<parsetree*> inheritemethods(scope* s);
vector<parsetree*> insertmethods(vector<parsetree*> m1, vector<parsetree*> m2);
int samemethod(parsetree* m1, parsetree* m2);
vector<parsetree*> containmethods(scope* s);
int cycliccheck(parsetree* c,vector<parsetree*> path);
int is_classmethod(parsetree* pt);
#endif
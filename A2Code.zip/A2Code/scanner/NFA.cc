#include "NFA.h"
#include <stdlib.h>
#include <vector>
#include "regex.h"
#include <iostream>

struct Transition NFA::transitionmaker(struct NState s1, struct NState s2, string t){
	struct Transition newT;
	newT.from = s1;
	newT.to = s2;
	newT.t=t;
	return newT;
};

NFA::NFA(){	//constructor
	num_alph=0;
	//set number of state to be 1
	num_state = 1;

	struct NState start;
	start.id=0;
	startid = start.id;
	start.kind="START";
	start.isEnd=0;
	states.push_back(start);
}


int NFA::is_end(int i) {
	return states.at(i).isEnd;
}

struct NState NFA::get_state(int i) {
  return states.at(i);
}

vector<string> NFA::get_alphas() {
	return alphs;
}

int NFA::is_terminal(int i) {
  return get_state(i).isEnd;
}

vector<string> NFA::getalphs(){
	return alphs;
}
vector<struct NState> NFA::getstates(){
	return states;
}
vector<struct NState> NFA::getterminals(){
	return terminals;
}
vector<struct Transition> NFA::gettrans(){
	return trans;
}
void NFA::setalphs(vector<string> newalphs){
	alphs = newalphs;
}
void NFA::setstates(vector<struct NState> newstates){
	states = newstates;
}
void NFA::setterminals(vector<struct NState> newterminals){
	terminals = newterminals;
}
void NFA::settrans(vector<struct Transition> newtrans){
	trans = newtrans;
}


vector<int> NFA::reach(int current, string a){
	vector<int> reachlist;
	
	int max = trans.size();
	for (int i=0; i<max; i++) {
		if (current == trans.at(i).from.id){
			if (trans.at(i).t == a) {
				// (trans.at(i).t == "^*" && a != "*")
				reachlist.push_back(trans.at(i).to.id);
			}
		}
	}
	
	return reachlist;
}


void NFA::add(string type, string word){
	//generate the new NFA created by the new type and word.
	RegEx RE(type,word);
	NFA newNFA = RE.convertToNFA();
	
	//alphs = alphs1 U alphs2
	/* e.g. alphs1 = ( a c d ) alphs2 = ( a b k) alphs = (a b c d k)*/
	vector<string> newalphs = newNFA.getalphs();
	vector<string>::iterator alphsit2;
	for(alphsit2 = newalphs.begin(); alphsit2 < newalphs.end(); alphsit2++)
	{
		vector<string>::iterator alphsit1; 
		int isIn = 0;
		for(alphsit1 = alphs.begin(); alphsit1 < alphs.end(); alphsit1++)
		{
			if(*alphsit1 == *alphsit2)
			{
				isIn = 1;
				break;
			}
		}
		if(!isIn)
		{
			num_alph += 1;
			alphs.push_back(*alphsit2);
		}
	}
	
	//the id of the states of the second NFA is added by number of states of the second NFA - 1, others remain unchange.
	/* e.g.
	NFA1: states (0 1 2 3 4) NFA2: states(0 1 2 3 4)  -> NFA: states ( 0 1 2 3 4 5 6 7) */
	vector<struct NState> newstates = newNFA.getstates();
	vector<struct NState>::iterator stateit2;
	for(stateit2 = newstates.begin() + 1; stateit2< newstates.end(); stateit2++)
	{
		struct NState tempstate;
		tempstate.id = (*stateit2).id + num_state - 1;
		tempstate.kind = (*stateit2).kind;
		tempstate.isEnd = (*stateit2).isEnd;
		if(tempstate.isEnd == 1)
			terminals.push_back(tempstate);
		states.push_back(tempstate);
	}
	
	//update start state
	if(newstates.at(0).isEnd == 1)
	{
		states.at(0) = newstates.at(0);
		terminals.push_back(newstates.at(0));
	}
	
	//update the transition
	/*all state that is not a start state must add num_state - 1 */
	vector<struct Transition> newtrans = newNFA.gettrans();
	vector<struct Transition>::iterator transitionit2;
	for(transitionit2 = newtrans.begin(); transitionit2 < newtrans.end();transitionit2++)
	{
		struct Transition temp = *transitionit2;
		if(temp.from.kind != "START" )
		{
			temp.from.id += (num_state - 1 );
		}
		if(temp.to.kind != "START")
		{
			temp.to.id += (num_state - 1 );
		}
		trans.push_back(temp);
	}
	//update num_state
	num_state = num_state + newNFA.num_state - 1;
}

struct NState NFA::getStart()
{
	return states.at(0);
}

NFA::~NFA(){	//Destructor

}




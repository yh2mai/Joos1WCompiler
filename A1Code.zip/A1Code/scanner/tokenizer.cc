#include <iostream>
#include <string>
#include <vector>
#include <assert.h>
#include "DFA.h"
#include "tokenizer.h"

using namespace std;

string DFA::getstatestring(int id)
{
	vector<struct DState>::iterator dsit;
	for(dsit = states.begin();dsit < states.end(); dsit ++)
	{
		if((*dsit).id == id)
			return (*dsit).kind;
	}

}

string DFA::getstatekind(int id)
{
	int size = states.size();
	for(int i = 0; i < size; i++)
	{
		if(states.at(i).id == id)
			return states.at(i).kind;
	}

	return "nothing found";
}

void printtoken(vector<struct Token> tokens){
	int max = tokens.size();
	for(int i=0;i < max;i++){
		cout << "\t" << tokens.at(i).kind << "\t" << tokens.at(i).lexeme << endl;
	}
}

//if we need to filter out s.
int filterout_huh(string s){
	if(s ==  "SPACE" || s == "COMMENT" || s == "LINETERMINATOR"){
		return 1;
	}
	return 0;
}

vector<struct Token> tokenizer(struct DFA d, string line, int *ret){
	line += " ";
	int len = line.length();	//length of code
	int current = d.start; 	//current state id
	int laststate = d.start;	//last terminal state id
	int lastpos = -1; 		//the position of last terminal state
	int nextstate;		//next state id
	string temp;	//alphabet
	string lastlexeme;
	string currentlexeme;
	string lastkind;	//the kind of last terminal state
	vector<struct Token> tokenlist;
	struct Token t;

	//debug
	//~ cout << "len = " << len << endl;

	//at this point return int of terminal state
	int i = 0;
	while(i<len){
		//debug
		//cout << "i = " << i << endl;
		//cout << "current = " << current << endl;
		//cout << "laststate = " << laststate << endl;
		//cout << "lastpos = " << lastpos << endl;
		temp = line.substr(i,1);
		nextstate = d.reach(current, temp);
		currentlexeme += temp;
		
		//debug
// cout << current << "--" << temp << "--> " << nextstate << endl; 
		
		//cannot reach next: store last token to tokenlist, initial all others
		if(nextstate == -1){
			if(lastlexeme.size() == 0)
			{
//~ cout << " WRONG TOKEN" << endl;
				*ret = 1;
				break;
			}
			lastkind = d.getstatekind(laststate);
			//if the token does not need to be filter out, store it to tokenlist
			if(!filterout_huh(lastkind)){
				//debug
// cout << lastkind << endl;
// cout << "insert token" << endl;
				t = Token(lastkind,lastlexeme);
				tokenlist.push_back(t);
			}
			i = lastpos + 1;
			current = d.start;
			laststate = d.start;
			currentlexeme.clear();
			lastlexeme.clear();
		}
		 //can reach next state
		else{
			current = nextstate;
			//if it is an accepting state, update laststate. lastlexeme and stringbuf
			if (d.get_state(current).isTerminal == 1){
				laststate = current;
				lastlexeme = currentlexeme;
				lastpos = i;
				i++;
			}
			//if it is a non-terminating state
			else{
				assert(d.get_state(current).isTerminal == 0);
				i++;
			}
		}
	}

	// cout << "print the tokens" << endl;
	// cout << "token size = " << tokenlist.size() << endl;
	// printtoken(tokenlist);
	return tokenlist;
}


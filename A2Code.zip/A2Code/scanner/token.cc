#include <string>
#include "token.h"

using namespace std;

Token::Token(std::string k, std::string l){
	kind = k;
	lexeme = l;
	i = -1;
}



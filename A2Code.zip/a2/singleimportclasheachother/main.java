import a.A;	//single import clash with each other.
import a.A;
public class main{
	main(){}
}
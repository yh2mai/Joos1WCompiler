package A;
public class a{
	public a(){}
}
public class scope{
	public int j = 1;
	scope(){}
	public int m(){
		int a;
		{
			int b;
		}
		{
			int c;
		}
	}
}
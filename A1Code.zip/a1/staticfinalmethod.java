public class staticfinalmethod{	
	static final int m(){}	//A static method cannot be final.
}
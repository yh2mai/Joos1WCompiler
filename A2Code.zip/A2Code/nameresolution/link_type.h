#ifndef __LINK_TYPE_H__
#define __LINK_TYPE_H__
#include "../parser/parsetree.h"
#include "../environment/scope.h"
#include <vector>

void link_type_node(parsetree* pt);
void link_type(parsetree* pt);
void link_class(parsetree* pt);
void link_type_interface(parsetree* pt);
void link_extend_interface(parsetree* pt);
int is_member(parsetree* pt, vector<parsetree*> interfaces);
int package_clash_withtype(parsetree* package1, parsetree* package2, string cname);
vector<string> stdlibs();
vector<string> primitivetype();
#endif
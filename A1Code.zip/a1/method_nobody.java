public class method_nobody{	//A method has a body if and only if it is neither abstract nor native.
	public static int m();
}
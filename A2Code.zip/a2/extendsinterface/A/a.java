package A;
public interface a{
}
#ifndef __DFA_H__
#define __DFA_H__

#include <vector>
#include <string>
#include <unordered_map>
#include "token.h"
#include "NFA.h"

struct DState {
  int id; // a unique number represent a state
  std::vector<int> ids; // ids of NStates
  std::string kind;
  int isTerminal;
	DState(int, std::string, int, std::vector<int>);
	DState() {}
};


struct DTransition {
  DState from; // initial state
  DState to; // end state
  std::string t; // the string that used from ��from�� to ��to�� (usually has just one char in it)
	DTransition(struct DState, struct DState, std::string);
	DTransition() {}
}; // e.g state1 "0" state2

void print_dstate(DState s);

class DFA{
  private:
    std::vector<std::string> alphs;	//an alphabet, sign, digit...
    std::vector<struct DState> states; //states
    // vector<int> terminals;  //terminals, represented by NState id number
    std::vector <struct DTransition> trans;  //transition
    int state_ctr; // = -1; // id counter = total number of current states - 1
	
  public:
	DFA();
    DFA(string dfafile);
    int start; // the start state id number
    int reach(int current, std::string a);
    unordered_map<std::string, int> ttable;
		
    void addState(struct DState);
		void determineId(struct DState* s);
		void determineKind(NFA nfa, struct DState* s);
		void determineTerminal(NFA nfa,struct DState* s);
		int has_state(struct DState* s); // returns 0 if DFA does not have state s
		struct DState get_state(int);
		
    void addTrans(struct DState, std::string a, struct DState);
    int get_ctr(); //return state_ctr
    int is_terminal(int);
		
		void transitionmaker(struct DState, std::string t, struct DState);
		void set_alphas(std::vector<string>);
		
		std::string getstatekind(int);
		std::vector<std::string> get_alphas();
		std::vector<struct DState> get_states();
		std::vector<struct DTransition> get_trans();
		void print_dfa();
		void write_dfa(string);
		std::string getstatestring(int id);
    // ~DFA();
};

DFA NFAtoDFA(NFA nfa);
#endif

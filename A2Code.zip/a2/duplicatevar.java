public class duplicatevar{
	duplicatevar(){}
	public int m()
	{
		int a = 1;
		int a = 1;	//duplicate variables
	}
}
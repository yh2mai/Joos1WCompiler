#ifndef __PARSETREE_H__
#define __PARSETREE_H__

#include <vector>
#include <string>
#include "lr1.h"
#include "../scanner/DFA.h"
#include <fstream>

class scope;
class parsetree{
	private:
		vector<parsetree*> children;
		string name;
		string lexeme;
		parsetree* parent;
		scope* s;
	public:
		scope* getscope();
		void setscope(scope*);
		parsetree* link;
		parsetree* getparent();
		parsetree* at(int i);
		parsetree* at(string);
		int size();
		parsetree(){}
		parsetree(string name, string lexeme);
		void addchild(parsetree *pt);
		string getname();
		string getlexeme();
		vector<parsetree*> getchildren();
		parsetree(LR1 lr1,vector<struct exrule> * derivations,string start, vector<struct Token> * tokens);
		parsetree(ifstream *f);
		void setparent(parsetree* p);
		void setchildren(vector<parsetree*>);
		void print(int );
		void write(ofstream *o);
};
parsetree* getpscope(parsetree* pt);
vector<string> get_all_terminals_in_pt(parsetree * pt);
vector<string> get_all_terminalsname_in_pt(parsetree* pt);
vector<string> getnumber(parsetree *pt);
vector<string> tokenize(string line);
int isTerminalnew(string symbol, LR1 lr1);
parsetree * ast(parsetree *pt);
int is_member(string a, vector<string> list);
void printindent(int k);
#endif
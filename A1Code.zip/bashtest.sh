#!/bin/bash
rm testout
for file in a1/*.java; do
	./joosc $file
	echo "$file: $?" >> testout
done


public class voidtype{	//The type void may only be used as the return type of a method.
	public int m()
	{
	void k = 1;
	}
}
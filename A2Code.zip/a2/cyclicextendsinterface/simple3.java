package A;
public interface simple3 extends simple2{}
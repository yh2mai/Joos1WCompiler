public class formalparameter{
	public int a(int b){ int c = a(1);}
	
}
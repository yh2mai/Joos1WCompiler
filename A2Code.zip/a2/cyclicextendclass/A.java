package A;
public class A extends Main
{
	public A(){}
}
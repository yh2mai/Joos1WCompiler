package A;
public class b{
	public b(){}
	public static int m(){}
}
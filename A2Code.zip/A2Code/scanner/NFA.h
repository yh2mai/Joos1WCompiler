#ifndef __NFA_H__
#define __NFA_H__

#include <vector>
#include <string>
#include "token.h"
using namespace std;

struct NState { // changed, state type is NState
  int id;
  string kind;
  int isEnd;
};

struct Transition {
  NState from; // initial state
  NState to; // end state
  string t; // the char that used from ��from�� to ��to�� single length string represent for single character, length 2 string represent for all characters except the second one.
}; // e.g state1 0 state2


class NFA{
	vector<string> alphs;	//an alphabet, sign, digit...
	vector<struct NState> states; //states
    // changed, vector of int ids
	// vector<struct State> terminals;  //terminals
    vector<struct NState> terminals;
	vector <struct Transition> trans;  //transition
	int startid;
	
	public:
	int num_alph;
	int num_state;
	NFA();
  // changed, add start id of the starting state
  // please initialize it somewhere
	vector<string> getalphs();
	vector<struct NState> getstates();
	vector<struct NState> getterminals();
	vector<struct Transition> gettrans();
	void setalphs(vector<string>);
	void setstates(vector<struct NState>);
	void setterminals(vector<struct NState>);
	void settrans(vector<struct Transition>);
	void add(string type, string word);
	struct Transition transitionmaker(struct NState, struct NState, string t);
	// changed, new function
  // return the ndf state whos id = i
  struct NState get_state(int i);
  
  // changed, add new function
  int is_terminal(int i); // returns 1 if states.at(i) is a temrinal state
  
  // changed
  vector<int> reach(int, string);
  
  // changed
  struct NState getStart(); // return the start state
	std::vector<string> get_alphas();
  int is_end(int i);
	/*
	word is a regular expression. 
	input("IF", "if")-> start e (e stands for absolone) 1, 1 i 2 , 2 f IF.  or ("ID", "[a-b]c*") -> start e (e stands for absolone) 3, 3 a 4, 4 c ID, ID c ID.
	*/
	~NFA();
};

#endif
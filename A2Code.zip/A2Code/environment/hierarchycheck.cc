#include "hierarchycheck.h"
#include "../nameresolution/link_type.h"
#include <vector>
#include <string>
#include <iostream>
#include <stack>
#define DEBUG true
extern vector<parsetree*> pts;
int hierarchycheck(scope* s)
{
	string name = scopetoclass_interfacename(s);
	if(name == "Object")
		return 0;
	parsetree* classp = NULL;
	if(s->classes.size() != 0)
		classp = s->classes.at(0);
	else
		classp = s->interfaces.at(0);
	vector<parsetree*> names{};
	vector<parsetree*> supers;
	scope* t = NULL;
	parsetree* c = NULL;
	if(s->classes.size() != 0)
	{
		t = s->classes.at(0)->getscope();
		c = s->classes.at(0);
		supers = superclassesandinterfaces(s->classes.at(0));
	}
	else
	{
		t = s->interfaces.at(0)->getscope();
		c = s->interfaces.at(0);
		supers = superclassesandinterfaces(s->interfaces.at(0));
	}
	cycliccheck(c,names);
	vector<parsetree*> inherite_methods = inheritemethods(s);
	for(int i =0;i < inherite_methods.size();i++)
	{
		for(int j =0; j < t->methods.size();j++)
		{
			if(samemethod(inherite_methods.at(i), t->methods.at(j)))
			{
				if(!sametype(inherite_methods.at(i)->at(0)->at(1), t->methods.at(j)->at(0)->at(1)))
				{
					if(DEBUG) cerr <<"A class or interface must not contain (declare or inherit) two methods with the same signature but different return types" << endl;
						exit(42);
				}
				if(!is_member("static", get_all_terminals_in_pt(t->methods.at(j)->at(0)->at(0))) && is_member("static", get_all_terminals_in_pt(inherite_methods.at(i)->at(0)->at(0))))
				{
					if(DEBUG) cerr <<"A nonstatic method must not replace a static method" << endl;
						exit(42);
				}
				if(is_member("protected",get_all_terminals_in_pt(t->methods.at(j)->at(0)->at(0))) && is_member("public", get_all_terminals_in_pt(inherite_methods.at(i)->at(0)->at(0))))
				{
					if(DEBUG) cerr <<"A protected method must not replace a public method. " << endl;
						exit(42);
				}
				if(is_member("static", get_all_terminals_in_pt(t->methods.at(j)->at(0)->at(0))) && scopetoclass_interfacename(inherite_methods.at(i)->getscope()->getparent()->getparent()) == "Object")
				{
					if(DEBUG) cerr << "A Static method can not replace an instance method." << endl;
						exit(42);
				}
				if(is_member("final",get_all_terminals_in_pt(inherite_methods.at(i)->at(0)->at(0))))
				{
					if(DEBUG) cerr <<"A method must not replace a final method" << endl;
						exit(42);
				}
			}
		}
	}
	vector<parsetree*> contain_methods = containmethods(s);
	for(int i = 0; i < contain_methods.size();i++)
	{
		if((is_member("abstract",get_all_terminals_in_pt(contain_methods.at(i)->at("MethodHeader")->at(0))) || "AbstractMethodDeclaration" == contain_methods.at(i)->getname()) && !is_member("abstract", get_all_terminals_in_pt(c->at(0))) && c->getname() == "ClassDeclaration")
		{
			if(DEBUG)
				cerr << "A class that contains (declares or inherits) any abstract methods must be abstract."<<endl;
				exit(42);
		}
	}
	vector<parsetree*> objectmethod = objectclass()->getscope()->methods;
	if(s->interfaces.size() != 0)
	{
		scope* sc = s->interfaces.at(0)->getscope();
		for(int i = 0; i < sc->methods.size(); i++)
		{
			for(int j = 0; j < objectmethod.size(); j++)
			{
				if(samemethod(objectmethod.at(j), sc->methods.at(i)))
				{
					if(is_member("final", get_all_terminals_in_pt(objectmethod.at(j)->at("MethodHeader")->at(0))))
					{
						if(DEBUG) cerr << "Interface Final MEthod from OBject" << endl;
							exit(42);
					}
					if(is_member("public", get_all_terminals_in_pt(sc->methods.at(i)->at("MethodHeader")->at(0))) && is_member("protected", get_all_terminals_in_pt(objectmethod.at(j)->at("MethodHeader")->at(0))))
					{
						if(DEBUG) cerr << "A protected method must not override a public method "<< endl;
						exit(42);
					}
				}
			}
		}
	}
	return 0;
}

parsetree* superclass(parsetree* pt)
{
	for(int i = 0 ; i < pt->size();i++)
	{
		if(pt->at(i)->getname() == "Super")
		{
			if(pt->at(i)->at(1)->getname() == "ID")
				return pt->at(i)->at(1)->link;
			else if(pt->at(i)->at(1)->getname() == "QualifiedName")
				return pt->at(i)->at(1)->at(2)->link;
		}
	}
	return objectclass();
}

parsetree* pttolink(parsetree* pt)
{
	if(pt->getname() == "ID")
		return pt->link;
	else
		return pt->at(2)->link;
}

vector<parsetree*> implementinterfaces(parsetree* pt)
{
	vector<parsetree*> ret;
	for(int i = 0 ; i < pt->size();i++)
	{
		if(pt->at(i)->getname() == "Interfaces")
		{
			parsetree* temp = pt->at(i)->at(1);
			while(temp->size() == 3)
			{
				ret.push_back(pttolink(temp->at(2)));
				temp = temp->at(0);
			}
			ret.push_back(pttolink(temp->at(0)));
		}
	}
	return ret;
}
vector<parsetree*> superclassesandinterfaces(parsetree* pt)
{
	if(pt->getname() == "ClassDeclaration")
	{
		vector<parsetree*> ret = implementinterfaces(pt);
		ret.push_back(superclass(pt));
		return ret;
	}
	else
	{
		vector<parsetree*> ret = superinterfaces(pt);
		return ret;
	}
}
vector<parsetree*> hopelessret{};
vector<parsetree*> superinterfaces(parsetree* pt)
{
	hopelessret.resize(0);
	for(int i = 0 ; i < pt->size();i++)
	{
		if(pt->at(i)->getname() == "ExtendsInterfaces")
		{
			parsetree* temp = pt->at(i);
			while(temp->size() == 3)
			{
				hopelessret.push_back(temp->at(2)->link);
				temp = temp->at(0);
			}
			hopelessret.push_back(temp->at(1)->link);
		}
	}
	return hopelessret;
}

vector<parsetree*> inheritemethods(scope* s)
{
	vector<parsetree*> ret;
	scope* temp= NULL;
	parsetree* clas=NULL;
	if(s->classes.size() != 0)
	{
		clas = s->classes.at(0);
		temp = s->classes.at(0)->getscope();
	}
	else
	{
		clas = s->interfaces.at(0);
		temp = s->interfaces.at(0)->getscope();
	}
	stack<vector<parsetree*>> mystack;
	vector<parsetree*> inheriteclass_interface = superclassesandinterfaces(clas);
	mystack.push(inheriteclass_interface);
	vector<parsetree*> now;
	int m = 1;
	while(mystack.size() != 0)
	{
		now = mystack.top();
		mystack.pop();
		if(now.size() == 1 && now.at(0)->at("ID")->getlexeme() == "Object")
		{
			if(m)
			{
				ret = insertmethods(ret, now.at(0)->getscope()->methods);
				m = 0;
			}
		}
		else
		{
			for(int i = 0; i < now.size();i++)
			{
				ret = insertmethods(ret,now.at(i)->getscope()->methods);
				vector<parsetree*> tempmethods = superclassesandinterfaces(now.at(i));
				mystack.push(tempmethods);
			}
		}
	}
	if(clas->getname() == "InterfaceDeclaration" && inheriteclass_interface.size() == 0)
	{
		ret = objectclass()->getscope()->methods;
	}
	return ret;
}

vector<parsetree*> insertmethods(vector<parsetree*> m1, vector<parsetree*> m2)
{
	vector<parsetree*> ret = m1;
	for(int i =0;i < m2.size();i++)
	{
		int replace = 0;
		for(int j =0 ;j < m1.size(); j++)
		{
			if(getmethodname(m1.at(j)) == getmethodname(m2.at(i)))
			{
				if(getpara_tree(m1.at(j)) == NULL)
				{
					if(getpara_tree(m2.at(i)) == NULL)
					{
						if(!sametype(m1.at(j)->at("MethodHeader")->at(1), m2.at(i)->at("MethodHeader")->at(1)))
						{
							if(DEBUG) cerr <<"A class or interface must not contain (declare or inherit) two methods with the same signature but different return types " << endl;
							exit(42);
						}
						if(((is_member("abstract", get_all_terminals_in_pt(m1.at(j)->at("MethodHeader")->at(0))) && (m2.at(i)->getname()!= "AbstractMethodDeclaration" && scopetoclass_interfacename(m2.at(i)->getscope()->getparent()->getparent()) != "Object")) || m1.at(j)->getname() == "AbstractMethodDeclaration" || (m1.at(j)->getscope()->getparent()->getparent()->classes.size() != 0 && scopetoclass_interfacename(m1.at(j)->getscope()->getparent()->getparent()) == "Object")) && !is_classmethod(m1.at(j)))
						{
							replace = 1;
							if(is_member("public", get_all_terminals_in_pt(m1.at(j)->at("MethodHeader")->at(0))) && is_member("protected", get_all_terminals_in_pt(m2.at(i)->at("MethodHeader")->at(0))))
							{
								if(DEBUG) cerr << "A protected method must not override a public method "<< endl;
								exit(42);
							}
							ret.at(j) = m2.at(i);
						}
						if((is_member("abstract", get_all_terminals_in_pt(m2.at(i)->at("MethodHeader")->at(0)))  && (m1.at(j)->getname() != "AbstractMethodDeclaration" &&scopetoclass_interfacename(m1.at(j)->getscope()->getparent()->getparent()) != "Object")) || m2.at(i)->getname() == "AbstractMethodDeclaration" || (m2.at(i)->getscope()->getparent()->getparent()->classes.size() != 0 && scopetoclass_interfacename(m2.at(i)->getscope()->getparent()->getparent()) == "Object"))
						{
							replace = 1;
						}
					}
				}
				else
				{
					if(getpara_tree(m2.at(i)) != NULL)
					{
						if(sameparameters(getpara_tree(m1.at(j)), getpara_tree(m2.at(i))))
						{
							if(!sametype(m1.at(j)->at("MethodHeader")->at(1), m2.at(i)->at("MethodHeader")->at(1)))
							{
								if(DEBUG) cerr <<"A class or interface must not contain (declare or inherit) two methods with the same signature but different return types" << endl;
								exit(42);
							}
							if(((is_member("abstract", get_all_terminals_in_pt(m1.at(j)->at("MethodHeader")->at(0)))&& (m2.at(i)->getname()!= "AbstractMethodDeclaration" && scopetoclass_interfacename(m2.at(i)->getscope()->getparent()->getparent()) != "Object")) || m1.at(j)->getname() == "AbstractMethodDeclaration" || (m1.at(j)->getscope()->getparent()->getparent()->classes.size() != 0 && scopetoclass_interfacename(m1.at(j)->getscope()->getparent()->getparent()) == "Object")) && !is_classmethod(m1.at(j)))
							{
								replace = 1;
								if(is_member("public", get_all_terminals_in_pt(m1.at(j)->at("MethodHeader")->at(0))) && is_member("protected", get_all_terminals_in_pt(m2.at(i)->at("MethodHeader")->at(0))))
								{
									if(DEBUG) cerr << "A protected method must not override a public method "<< endl;
									exit(42);
								}
								ret.at(j) = m2.at(i);
							}
							if((is_member("abstract", get_all_terminals_in_pt(m2.at(i)->at("MethodHeader")->at(0)))&& (m1.at(j)->getname() != "AbstractMethodDeclaration" && scopetoclass_interfacename(m1.at(j)->getscope()->getparent()->getparent()) != "Object")) || m2.at(i)->getname() == "AbstractMethodDeclaration"|| (m2.at(i)->getscope()->getparent()->getparent()->classes.size() != 0 && scopetoclass_interfacename(m2.at(i)->getscope()->getparent()->getparent()) == "Object"))
							{
								replace = 1;
							}
						}
					}
				}
			}
		}
		if(replace != 1)
			ret.push_back(m2.at(i));
	}
	return ret;
}

int samemethod(parsetree* m1, parsetree* m2)
{
	if(getmethodname(m1) == getmethodname(m2))
	{
		if(getpara_tree(m1) == NULL)
		{
			if(getpara_tree(m2) == NULL)
			{
				return 1;
			}
		}
		else
		{
			if(getpara_tree(m2) != NULL)
			{
				if(sameparameters(getpara_tree(m1), getpara_tree(m2)))
				{
					return 1;
				}
			}
		}
	}
	return 0;
}

vector<parsetree*> containmethods(scope* s)
{
	vector<parsetree*> inherite_methods = inheritemethods(s);
	vector<parsetree*> declare_methods;
	if(s->classes.size() != 0)
		declare_methods = s->classes.at(0)->getscope()->methods;
	else
		declare_methods = s->interfaces.at(0)->getscope()->methods;
	for(int i =0;i< inherite_methods.size();i++)
	{
		int k = 1;
		for(int j =0; j< declare_methods.size();j++)
		{
			if(samemethod(inherite_methods.at(i),declare_methods.at(j)))
			{
				k = 0;
			}
		}
		if(k)
		{
			declare_methods.push_back(inherite_methods.at(i));
		}
	}
	return declare_methods;
}			

int cycliccheck(parsetree* c, vector<parsetree*> path)
{
	vector<parsetree*> supers = superclassesandinterfaces(c);
	if(is_member(c, path))
	{
		if(DEBUG)
			cerr << "The hierarchy must be acyclic." << endl;
		exit(42);
	}
	else
	{
		path.push_back(c);
		for(int i = 0;i < supers.size();i++)
		{
			if(classname(supers.at(i)) != "Object" && cycliccheck(supers.at(i), path))
				return 1;
		}
	}
	return 0;
}

int is_classmethod(parsetree* pt)
{
	scope* s = pt->getscope();
	while(s->getname() != "CompilationUnit")
		s = s->getparent();
	if(s->classes.size() != 0)
		return 1;
	else 
		return 0;
}
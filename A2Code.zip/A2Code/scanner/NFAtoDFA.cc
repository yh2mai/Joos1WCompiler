// Translate a NFA to DFA
// Assuming the NFA does not have any episilon transitions
#include <string>
#include <vector>
#include <iostream>
#include "NFA.h"
#include "DFA.h"
using namespace std;


struct DState convertState(struct NState s) {
  struct DState cstate;
	cstate.id = s.id;
  cstate.kind = s.kind;
  cstate.ids.push_back(s.id);
	cstate.isTerminal = s.isEnd;
  return cstate;
};


DFA NFAtoDFA(NFA nfa) {
  int i,j;
  DFA dfa = DFA();
	dfa.set_alphas(nfa.getalphs());
	
	// cout << "====DFA alphas===" << endl;
	// for (int i = 0; i < dfa.get_alphas().size(); i++) {
		// cout << i << ") " << dfa.get_alphas().at(i) << endl;
	// }
	// cout << "====DFA alphas END===" << endl;
	
	
  vector<DState> wlist;	
	wlist.push_back(convertState(nfa.getStart()));
	dfa.addState(wlist.at(0));
	
  while (wlist.size() > 0) { // while the worklist is not empty
// cout << "pop worklist" << endl;
    struct DState from = wlist.at(0);    
    wlist.erase(wlist.begin());
// print_dstate(from);
		
    for (i = 0; i < nfa.get_alphas().size(); i++) { // for each alphabet
		string alpha = nfa.get_alphas().at(i);
		struct DState to;
		
// cout << "For alpha " << alpha << ">>>>>>>>>" << endl;

      vector<int> combined; 
			// states(represented by id in nfa)
			// that are reachable from (every states in 'from')
			// using alphs.at(i) in NFA
      
      for (j = 0; j < from.ids.size(); j++) { // for each state in the from
        vector<int> reachables = nfa.reach(from.ids.at(j), alpha);
				if (reachables.size() < 1) {
// cout << "The state cannot reach anywhere use " << alpha << " " << endl;
					continue;
				}
// cout << "The poped state can reach: ";
// for (int z = 0; z < reachables.size(); z++) {
	// cout << reachables.at(z) << " " ;
// }
// cout << endl;

        combined.insert(combined.end(), reachables.begin(), reachables.end());
        // there will be duplicate ids in combined, but will be cleared out in has_state
      }
      
			if (combined.size() < 1) {
				continue;
cout << "DState cannot reach anywhere using " << alpha << " " << endl;
			}
			
      to.ids = combined;
      
      combined.clear();
			
      if (!dfa.has_state(&to)) {
        dfa.determineId(&to);
        dfa.determineKind(nfa, &to);
        dfa.determineTerminal(nfa,&to);
				dfa.addState(to); 
        wlist.push_back(to);
// cout << "New DState" << endl;
// print_dstate(to);
      }
// cout << "add tran : " << from.id << " --" << alpha << "--> " << to.id << endl;
			dfa.addTrans(from, alpha, to);
    }
  }
  return dfa;
}

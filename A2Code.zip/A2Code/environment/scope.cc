#include "scope.h"
#include "../parser/parsetree.h"
#include <string>
#include <iostream>
#define DEBUG true

vector<string> scopes{"CompilationUnit","ClassDeclaration","ConstructorDeclaration","MethodDeclaration","Block","ForStatementNoShortIf","ForStatement","ConstructorBody","InterfaceDeclaration","AbstractMethodDeclaration"};
extern vector<parsetree*> pts;
scope::scope(){
	name = "";
	parent = NULL;
	package = NULL;
}
scope::scope(string n){
	name = n;
	parent = NULL;
	package = NULL;
}
int scope::size(){
	return children.size();
}
scope* scope::at(int i){
	return children.at(i);
}

scope* scope::getparent(){
	return parent;
}

void scope::setparent(scope* s)
{
	parent = s;
}
string scope::getname()
{
	return name;
}
void mark_scope_buildenv(parsetree* pt)
{
	string name = pt->getname();
	if(is_member(name,scopes))
	{
		scope * temp = new scope(pt->getname());
		if(temp->getname() != "CompilationUnit")
		{
			temp->setparent(pt->getparent()->getscope());
			temp->getparent()->addchild(temp);
		}
		pt->setscope(temp);
	}
	else
	{
		pt->setscope(pt->getparent()->getscope());
	}
	if(name == "PackageDeclaration")
	{
		pt->getscope()->package = pt;
	}
	else if(name == "SingleTypeImportDeclaration")
	{
		if(singleimport_clash_eachother(pt))
			exit(42);
		pt->getscope()->singleimports.push_back(pt);
	}
	else if(name == "TypeImportOnDemandDeclaration")
	{
		pt->getscope()->ondemandimports.push_back(pt);
	}
	else if(name == "ClassDeclaration")
	{
		if(class_clash_singleimport(pt))
			exit(42);
		if(class_clash_eachother(pt))
			exit(42);
		string cname = classname(pt);
		pt->getscope()->getparent()->classes.push_back(pt);
	}
	else if(name == "InterfaceDeclaration")
	{
		if(interface_clash_singleimport(pt))
			exit(42);
		pt->getscope()->getparent()->interfaces.push_back(pt);
	}
	else if(name == "MethodDeclaration")
	{
		if(duplicatemethod(pt, pt->getscope()->getparent()))
		{
			if(DEBUG)
				cerr<< "A class or interface must not declare two methods with the same signature (name and parameter types)."<<endl;
			exit(42);
		}
		if(is_member("abstract",get_all_terminals_in_pt(pt->at("MethodHeader")->at(0))) && !is_member("abstract", get_all_terminals_in_pt(pt->getscope()->getparent()->getparent()->classes.at(0)->at(0))))
		{
			if(DEBUG)
				cerr << "A class that contains (declares or inherits) any abstract methods must be abstract."<<endl;
				exit(42);
		}
		pt->getscope()->getparent()->methods.push_back(pt);
	}
	else if(name == "AbstractMethodDeclaration")
	{
		if(duplicatemethod(pt,pt->getscope()->getparent()))
		{
			if(DEBUG)
				cerr<< "A class or interface must not declare two methods with the same signature (name and parameter types)."<<endl;
			exit(42);
		}
		pt->getscope()->getparent()->methods.push_back(pt);
	}
	else if(name == "FieldDeclaration")
	{
		scope* s = pt->getscope();
		for(int i = 0; i < s->fields.size(); i++)
		{
			if(fieldname(pt) == fieldname(s->fields.at(i)))
			{
			cerr << "Duplicated Fields." << endl;
			exit(42);
			}
		}
		pt->getscope()->fields.push_back(pt);
	}
	else if(name == "LocalVariableDeclaration" || name == "FormalParameter")
	{
		scope* s = pt->getscope();
		while(s->getname() != "CompilationUnit")
		{
			for(int i = 0; i < s->vars.size(); i++)
			{
				if(varname(pt) == varname(s->vars.at(i)))
				{
				cerr << "Duplicated Localvariables." << endl;
				exit(42);
				}
			}
			s = s->getparent();
		}
		pt->getscope()->vars.push_back(pt);
	}
	else if(name == "ConstructorDeclaration")
	{
		if(duplicatecons(pt, pt->getscope()->getparent()))
		{
			if(DEBUG)
				cerr<< "A class must not declare two constructors with the same parameter types"<<endl;
			exit(42);
		}
		pt->getscope()->getparent()->cons.push_back(pt);
	}
	for(int i =0 ;i < pt->size();i++)
	{
		mark_scope_buildenv(pt->at(i));
	}
}

void scope::addchild(scope* s)
{
	children.push_back(s);
}

void scope::print(int i)
{
	printindent(i);
	if(DEBUG)cerr << name << endl;
	if(DEBUG)
	{
		printindent(i);
		cerr << "Classes: " ;
		for(int j = 0 ; j < classes.size();j++)
		{
			cerr << classes.at(j)->at("ID")->getlexeme() << "  ";
		}
		cerr << endl;
	}
	if(DEBUG)
	{
		printindent(i);
		cerr<< "Interfaces: ";
		for(int j =0 ; j < interfaces.size(); j++)
		{
			cerr << interfaces.at(j)->at("ID")->getlexeme() << "  ";
		}
		cerr << endl;
	}
	if(DEBUG)
	{
		printindent(i);
		cerr << "Methods: ";
		for(int j =0 ; j < methods.size(); j++)
		{
			cerr << methods.at(j)->at("MethodHeader")->at("MethodDeclarator")->at("ID")->getlexeme() << "  ";
		}
		cerr << endl;
	}
	if(DEBUG)
	{
		printindent(i);
		cerr << "Constructors: ";
		for(int j =0 ; j < cons.size(); j++)
		{
			cerr << cons.at(j)->at("ConstructorDeclarator")->at("ID")->getlexeme() << "  ";
		}
		cerr << endl;
	}
	if(DEBUG)
	{
		printindent(i);
		cerr << "Fields: ";
		for(int j =0 ; j < fields.size(); j++)
		{
			cerr << fieldname(fields.at(j)) << "  ";
		}
		cerr << endl;
	}
	if(DEBUG)
	{
		printindent(i);
		cerr << "LocalVariables: ";
		for(int j =0 ; j < vars.size(); j++)
		{
			cerr << varname(vars.at(j)) << "  ";
		}
		cerr << endl;
	}
	for(int j = 0 ;j < children.size(); j++)
	{
		at(j)->print(i+name.length());
	}
}

string fieldname(parsetree* pt)
{
	return pt->at("VariableDeclarator")->at("ID")->getlexeme();
}

string varname(parsetree* pt)
{
	if(pt->getname() == "LocalVariableDeclaration")
		return pt->at("VariableDeclarator")->at("ID")->getlexeme();
	else
		return pt->at("ID")->getlexeme();
}

string classname(parsetree* pt)
{
	return pt->at("ID")->getlexeme();
}

string interfacename(parsetree* pt)
{
	return pt->at("ID")->getlexeme();
}

int class_clash_singleimport(parsetree* pt)
{
	string cname = classname(pt);
	scope * s = pt->getscope()->getparent();
	for(int i =0 ; i < s->singleimports.size();i++)
	{
		if(singleimportclassname(s->singleimports.at(i)) == cname)
		{
			if(s->package != NULL)
			{
				if(!samepackage(s->singleimports.at(i)->at("QualifiedName")->at(0), s->package->at(1)))
				{
				if(DEBUG) cerr << "No single-type-import declaration clashes with the class declared in the same file."<<endl;
				return 1;
				}
			}
			else
			{
				if(DEBUG) cerr << "No single-type-import declaration clashes with the class declared in the same file."<<endl;
				return 1;
			}
		}
	}
	return 0;
}

int interface_clash_singleimport(parsetree* pt)
{
	string iname = interfacename(pt);
	scope * s = pt->getscope()->getparent();
	for(int i =0 ; i < s->singleimports.size();i++)
	{
		if(singleimportclassname(s->singleimports.at(i)) == iname)
		{
			if(s->package != NULL)
			{
				if(!samepackage(s->singleimports.at(i)->at("QualifiedName")->at(0), s->package->at(1)))
				{
				if(DEBUG) cerr << "No single-type-import declaration clashes with the interface declared in the same file."<<endl;
				return 1;
				}
			}
			else
			{
				if(DEBUG) cerr << "No single-type-import declaration clashes with the interface declared in the same file."<<endl;
				return 1;
			}
		}
	}
	return 0;
}
		
string singleimportclassname(parsetree* pt)
{
	return pt->at("QualifiedName")->at(2)->getlexeme();
}

int singleimport_clash_eachother(parsetree* pt)
{
	string iname = singleimportclassname(pt);
	scope * s = pt->getscope();
	for(int i =0 ; i < s->singleimports.size();i++)
	{
		if(singleimportclassname(s->singleimports.at(i)) == iname && !samepackage(s->singleimports.at(i)->at("QualifiedName")->at(0), pt->at("QualifiedName")->at(0)))
		{
			if(DEBUG) cerr << "No two single-type-import declarations clash with each other."<<endl;
			return 1;
		}
	}
	return 0;
}

int samepackage(parsetree* pt, parsetree* pt2)
{
	if(pt->size() == pt2->size() && pt->getname() == pt2->getname() && pt->getlexeme() == pt2->getlexeme())
	{
		for(int i = 0 ; i < pt->size(); i ++)
		{
			int ret = samepackage(pt->at(i), pt2->at(i));
			if(ret == 0)
				return 0;
		}
		return 1;
	}
	else
	{
		return 0;
	}
	return 0;
}

parsetree* singleimporttoclass(parsetree* pt)
{
	for(int i =0 ;i < pts.size(); i++)
	{
		if(pts.at(i)->getscope()->package != NULL)
		{
			if(samepackage(pt->at("QualifiedName")->at(0), pts.at(i)->getscope()->package->at(1)))
			{
				if(pts.at(i)->getscope()->classes.size() != 0 && classname(pts.at(i)->getscope()->classes.at(0)) == pt->at("QualifiedName")->at(2)->getlexeme())
					return pts.at(i)->getscope()->classes.at(0);
				else if(pts.at(i)->getscope()->interfaces.size() != 0 && interfacename(pts.at(i)->getscope()->interfaces.at(0)) == pt->at("QualifiedName")->at(2)->getlexeme())
					return pts.at(i)->getscope()->interfaces.at(0);
			}
		}
	}
	if(DEBUG) cerr << "Single import is not a legal class." << endl;
	exit(42);
}

vector<parsetree*> matchclasses_ondemand(parsetree* pt, string cname)
{
	vector<parsetree*> ret;
	for(int i =0 ;i < pts.size();i ++)
	{
		if(pts.at(i)->getscope()->package != NULL)
		{
			if(packagematch(pt->at(1), pts.at(i)->getscope()->package->at(1)))
			{
				if(pts.at(i)->getscope()->classes.size() != 0 && classname(pts.at(i)->getscope()->classes.at(0)) == cname)
					ret.push_back(pts.at(i)->getscope()->classes.at(0));
				if(pts.at(i)->getscope()->interfaces.size() != 0 && interfacename(pts.at(i)->getscope()->interfaces.at(0)) == cname)
					ret.push_back(pts.at(i)->getscope()->interfaces.at(0));
			}
		}
	}
	return ret;
}

string scopetoclass_interfacename(scope* s)
{
	if(s->classes.size() != 0)
		return classname(s->classes.at(0));
	else
		return interfacename(s->interfaces.at(0));
}

int scopeisclass(scope* s)
{
	if(s->classes.size() != 0)
		return 1;
	else
		return 0;
}

int duplicatemethod(parsetree* pt, scope* s)
{
	string methodname = getmethodname(pt);
	parsetree* para_tree = getpara_tree(pt);
	for(int i =0 ;i < s->methods.size(); i++)
	{
		string methodname2 = getmethodname(s->methods.at(i));
		if(methodname == methodname2)
		{
			parsetree* para_tree2 = getpara_tree(s->methods.at(i));
			if(para_tree == NULL)
			{
				if(para_tree2 == NULL)
				{
					return 1;
				}
			}
			else
			{
				if(para_tree2 != NULL)
				{
					if(sameparameters(para_tree, para_tree2))
						return 1;
				}
			}
		}
	}
	return 0;		
}

string getmethodname(parsetree* pt)
{
	return pt->at("MethodHeader")->at("MethodDeclarator")->at("ID")->getlexeme();
}

parsetree* getpara_tree(parsetree* pt)
{
	if(pt->getname() == "MethodDeclaration" || pt->getname() == "AbstractMethodDeclaration")
	{
		if(pt->at("MethodHeader")->at("MethodDeclarator")->size() == 4)
		{
			return pt->at("MethodHeader")->at("MethodDeclarator")->at(2);
		}
		else
			return NULL;
	}
	else if(pt->getname() == "ConstructorDeclaration")
	{
		if(pt->at("ConstructorDeclarator")->size() == 4)
		{
			return pt->at("ConstructorDeclarator")->at(2);
		}
		else
			return NULL;
	}
}

int sameparameters(parsetree* pt1, parsetree* pt2)
{
	parsetree* temp1 = pt1;
	parsetree* temp2 = pt2;
	while(true)
	{
		if(temp1->size() == 3 && temp2->size()== 3 && sametype(temp1->at("FormalParameter")->at("Type"), temp2->at("FormalParameter")->at("Type")))
		{
			temp1 = temp1->at(0);
			temp2 = temp2->at(0);
		}
		else if(temp1->size() == 1 && temp2->size() == 1)
		{
			if(sametype(temp1->at("FormalParameter")->at("Type"), temp2->at("FormalParameter")->at("Type")))
				return 1;
			else
				return 0;
		}
		else
			return 0;
	}
	return 0;
}

int sametype(parsetree* pt1, parsetree* pt2)
{
	if(pt1->getname() == "VOID" || pt2->getname() == "VOID")
	{
		return pt1->getname() == pt2->getname();
	}
	string type1;
	if(pt1->at(0)->getname() == "ID")
		type1 = pt1->at(0)->getlexeme();
	else if(pt1->at(0)->getname() == "QualifiedName")
		type1 = pt1->at(0)->at(2)->getlexeme();
	else if(pt1->at(0)->getname() == "ArrayType")
		type1 = pt1->at(0)->at(0)->getlexeme();
	else
		type1 = pt1->at(0)->getname();
	string type2;
	if(pt2->at(0)->getname() == "ID")
		type2 = pt2->at(0)->getlexeme();
	else if(pt2->at(0)->getname() == "QualifiedName")
		type2 = pt2->at(0)->at(2)->getlexeme();
	else if(pt2->at(0)->getname() == "ArrayType")
		type2 = pt2->at(0)->at(0)->getlexeme();
	else
		type2 = pt2->at(0)->getname();
	return type1 == type2;
}

int duplicatecons(parsetree* pt, scope* s)
{
	parsetree* para_tree1 = getpara_tree(pt);
	for(int i =0 ;i < s->cons.size();i++)
	{
		parsetree* para_tree2 = getpara_tree(s->cons.at(i));
		if(para_tree1 == NULL)
		{
			if(para_tree2 == NULL)
				return 1;
		}
		else
		{
			if(para_tree2 != NULL)
			{
				if(sameparameters(para_tree1, para_tree2))
					return 1;
			}
		}
	}
	return 0;
}

parsetree* objectclass()
{
	for(int i =0 ;i < pts.size();i++)
	{
		if(scopetoclass_interfacename(pts.at(i)->getscope()) == "Object")
			return pts.at(i)->getscope()->classes.at(0);
	}
	if(DEBUG) cerr << "object class not found." << endl;
}

int packagematch(parsetree* pt1, parsetree* pt2)
{
	parsetree* temp1 = pt1;
	parsetree* temp2 = pt2;
	while(temp1->getname() == "QualifiedName")
	{
		temp1 = temp1->at(0);
	}
	while(temp2->getname() == "QualifiedName")
		temp2 = temp2->at(0);
	while(temp1->getname() != "TypeImportOnDemandDeclaration")
	{
		if(temp1->size() == 0)
		{
			if(temp1->getlexeme() == temp2->getlexeme())
			{
				temp1 = temp1->getparent();
				temp2 = temp2->getparent();
			}
			else
				return 0;
		}
		else
		{
			if(temp1->at(2)->getlexeme() == temp2->at(2)->getlexeme())
			{
				temp1 = temp1->getparent();
				temp2 = temp2->getparent();
			}
			else
				return 0;
		}
	}
	return 1;
}

int class_clash_eachother(parsetree* pt)
{
	for(int i =0 ;i < pts.size();i++)
	{
		parsetree* temp = pts.at(i);
		if(scopetoclass_interfacename(temp->getscope()) == classname(pt))
		{
			if(pt->getscope()->getparent()->package != NULL && temp->getscope()->package != NULL &&samepackage(pt->getscope()->getparent()->package, temp->getscope()->package))
			{	if(DEBUG) cerr << "Duplicate classes." << endl;
				exit(42);
			}
		}
	}
	return 0;
}
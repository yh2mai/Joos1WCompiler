package B;
public abstract class b{
	public b(){}
	public abstract int m();
}
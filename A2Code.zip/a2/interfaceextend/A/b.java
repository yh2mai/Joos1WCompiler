package A;
public interface b{}
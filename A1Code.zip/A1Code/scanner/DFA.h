#ifndef __DFA_H__
#define __DFA_H__

#include <vector>
#include <string>

struct DState {
  int id; // a unique number represent a state
  std::vector<int> ids; // ids of NStates
  std::string kind;
  int isTerminal;
  DState(int, std::string, int, std::vector<int>);
	DState() {}
};

struct DTransition {
  DState from; // initial state
  DState to; // end state
  std::string t; // the string that used from ��from�� to ��to�� (usually has just one char in it)
	DTransition(struct DState, struct DState, std::string);
	DTransition() {}
}; // e.g state1 "0" state2

class DFA{
	private:
		std::vector<std::string> alphs;	//an alphabet, sign, digit...
		std::vector<struct DState> states; //states
		std::vector <struct DTransition> trans;  //transition
		 int state_ctr; // = -1; // id counter = total number of current states - 1
		 
	public:
		DFA();
		DFA(std::string dfafile);
		int start; // the start state id number
		int reach(int current, std::string a);
		struct DState get_state(int);
		std::string getstatekind(int);
		std::string getstatestring(int id);
};

#endif
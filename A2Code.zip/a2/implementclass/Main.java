import A.a;
public class Main implements a{		//implement a class should be error
	Main(){}
}
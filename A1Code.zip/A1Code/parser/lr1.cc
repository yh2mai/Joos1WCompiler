#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include "lr1.h"
#include "../scanner/token.h"
#include <map>

using namespace std;

void print_strings(vector<string> s) {
	for (int i = 0; i < s.size(); i++) {
		cout << "[" << s.at(i) << "] ";
	}
	cout << endl;
}

void print_ints(vector<int> s) {
	for (int i = 0; i < s.size(); i++) {
		cout << "[" << s.at(i) << "] ";
	}
	cout << endl;
}


void filter_lineterminator(vector<string> *tokens) {
	for (int i = 0; i < tokens->size(); i++) {
		if (tokens->at(i) == "LINETERMINATOR") {
			tokens->erase(tokens->begin()+i);
			i--;
		}
	}
}	
//
rs stringtors(string s){
	if(s == "reduce"){return REDUCED;}
	else if(s == "shift"){return SHIFT;}
	return ERROR;
}

//separate s by x, and store the pieces to a vector
vector<string> stringtovector(string s, string x){
	int size = s.length();
	vector<string> r;
	string buf;
	string temp;
	int i = 0;
	for (i;i<size;i++){
		temp = s.substr(i,1);
		if(temp==x && buf!=""){
			r.push_back(buf);
			buf = "";
		}
		else{
			buf+=temp;
		}
	}
	return r;
}


vector<string> LR1::getterminals() {
	return terminals;
}

exrule::exrule(string f, vector<string> t){
	from = f;
	to = t;
}

void exrule::print(){
	int size = to.size();
	cout << from;
	for(int i=0;i<size;i++){
		cout << " " << to.at(i); 
	}
	cout << endl;
}

rsrule::rsrule(int f, string m, rs k, int t){
    from = f;
    middle = m;
    kind = k;
    to = t;
}

void rsrule::print(){
	cout << from << " " << middle << " " << kind << " " << to << endl;
}

vector<string> TokensToStrings(vector<struct Token> tokens) {
	vector<string> strings;
	for (int i = 0; i < tokens.size(); i++) {
		strings.push_back(tokens.at(i).kind);
	}
	return strings;
}

void decorate(vector<struct Token> *tokens){
	struct Token bof("BOF","");
	struct Token eof("EOF","");
	tokens->insert(tokens->begin(),bof);
	tokens->push_back(eof);
}

void shift(vector<string> *a, vector<string> *b) {
	// push the first element in b onto a. ease first element in b
	a->push_back(b->at(0));
	b->erase(b->begin());
}

struct exrule LR1::get_ex(int k) {
	return exrules.at(k);
}

void LR1::set_start(string s){
	start = s;
}

void LR1::add_n_terminal(string s){
	n_terminals.push_back(s);
}

void LR1::add_terminal(string s){
	terminals.push_back(s);
}

void LR1::add_rsrule(int f,string m,rs k,int t){
    struct rsrule rr(f,m,k,t);
    rsrules.push_back(rr);
}


vector<string> str_tokenize(string s) {
	string ss = s;
	vector<string> strings;
	istringstream is(ss);
	while (is) {
		string word;
		is >> word;
		strings.push_back(word);
	}
	return strings;
}

LR1::LR1(string filename){
	ifstream file;
	file.open(filename);
	string buf;
	int num_terms, num_nonterms, num_productions, num_trans;

//cout << "saving terminals" << endl;
	// save terminals
	getline(file, buf);
	num_terms = atoi(buf.c_str());
	for (int i = 0; i < num_terms; i++) {
		getline(file, buf);
		terminals.push_back(buf);
		terminals_hash[buf] = 0;
	}

//cout << "saving non-terminals" << endl;	
	// save non-terminals
	getline(file, buf);
	num_nonterms = atoi(buf.c_str());
	for (int i = 0; i < num_nonterms; i++) {
		getline(file, buf);
		n_terminals.push_back(buf);
	}

//cout << "saving states" << endl;
	// save starting state
	getline(file, buf);
	start = buf;

//cout << "saving productions" << endl;	
	// save productions
	getline(file, buf);
	num_productions = atoi(buf.c_str());
	for (int i = 0; i < num_productions; i++) {

		getline(file, buf);
// cout << "production: " << buf << endl;
		struct exrule r;
		vector<string> strings = str_tokenize(buf);
		string from = strings.at(0);
		strings.erase(strings.begin());
		strings.resize(strings.size() - 1);
		r = exrule(from, strings);
		exrules.push_back(r);
	}

//cout << "saving states" << endl;
	// save sates
	getline(file, buf);
	
//cout << "saving trans" << endl;
	// save transitions
	getline(file, buf);
	num_trans = atoi(buf.c_str());
	for (int i = 0; i < num_trans; i++) {
		getline(file, buf);
		vector<string> tran = str_tokenize(buf);
		
		string from, middle, k ,to;
		from = tran.at(0);
		middle = tran.at(1);
		k = tran.at(2);
		to = tran.at(3);
		rs way;
		if (k == "shift") { way = SHIFT;}
		else if (k == "reduce") {way = REDUCED;}
		else way = ERROR;
		
		struct rsrule r;
		r = rsrule(atoi(from.c_str()), middle, way, atoi(to.c_str()));
		rsrules.push_back(r);
	}
}

void LR1::print(){
	int i;
	int size = terminals.size();
	//printout terminals
	cout << size << endl;
	for(i=0;i<size;i++){
		cout << terminals.at(i) << endl;
	}
	//
	//printout non-terminals
	size = n_terminals.size();
	cout << size << endl;
	for(i=0;i<size;i++){
		cout << n_terminals.at(i) << endl;
	}
	//printout start symbols
	cout << start << endl;
	//printout exrules
	size = exrules.size();
	cout << size << endl;
	for(i=0;i<size;i++){
		exrules.at(i).print();
	}
	//printout num_state
	cout << num_state << endl;
	//printout rsrules
	size = rsrules.size();
	cout << size << endl;
	for(i=0;i<size;i++){
		rsrules.at(i).print();
	}
}


int dec_range_check(string s){
	int maxdec = 2147483647;
	int mindec = -2147483648;

	//if s is out of length
	if( ((s.substr(0,1) == "-")&&(s.length()>11)) ||
	 ((s.substr(0,1) != "-")&&(s.length()>10)) ){
		return 0;
	}
	//normal check
	if( (mindec<strtol(s.c_str(),NULL,0)) &&
	(strtol(s.c_str(),NULL,0)<maxdec) ){
		return 1;
	}
	//failed test
	return 0;
}

int oct_range_check(string s){
	int maxoct = 017777777777; 
	int minoct = -020000000000; 

	//if s is out of length
	if( ((s.substr(0,1) == "-")&&(s.length()>13)) ||
	 ((s.substr(0,1) != "-")&&(s.length()>12)) ){
		return 0;
	}
	//normal check
	if( (minoct<strtol(s.c_str(),NULL,0)) &&
	(strtol(s.c_str(),NULL,0)<maxoct) ){
		return 1;
	}
	//failed test
	return 0;
}

int hex_range_check(string s){
	int maxhex = 0x7fffffff; 
	int minhex = -0x80000000; 

	//if s is out of length
	if( ((s.substr(0,1) == "-")&&(s.length()>11)) ||
	 ((s.substr(0,1) != "-")&&(s.length()>10)) ){
		return 0;
	}
	//normal check
	if( (minhex<strtol(s.c_str(),NULL,0)) &&
	(strtol(s.c_str(),NULL,0)<maxhex) ){
		return 1;
	}
	//failed test
	return 0;
}

int check_range(vector<Token> tokens){
	int max = tokens.size();
	string k;
	for(int i=0;i<max;i++){
		k = tokens.at(i).kind;
		//check dec range
		if(k=="DECIMALINTEGER"){
			if(dec_range_check(tokens.at(i).lexeme) == 0){
				cout << "REJECTED!!" << endl;
				return 42;
			}
		}
		//check oct range
		if(k=="OCTINTEGER"){
			if(oct_range_check(tokens.at(i).lexeme) == 0){
				cout << "REJECTED!!" << endl;
				return 42;
			}
		}
		if(k=="HEXINTEGER"){
			if(hex_range_check(tokens.at(i).lexeme) == 0){
				cout << "REJECTED!!" << endl;
				return 42;
			}
		}
	}
}

int LR1::parse(vector<Token> tokens)
{
//cout << "STARTING PARSING..." << endl;
	string eof = "EOF";
	string bof = "BOF";

	//check range
	//~ if(check_range(tokens)==42){return 42;}
	//cout << "=========passed check range!!!=========" << endl;
	
	int state_cur;
	vector<string> left; // consumed input that are reduced ( maybe reduced more)
	vector<string> right; // original tokens.kind
	vector<int> state_log; // keep track of states visited
	// tokens.at(0).kind = "S";
	decorate(&tokens);
	right = TokensToStrings(tokens);
	filter_lineterminator(&right);
	
//~ cout << "right stringlized..." << endl;
//~ print_strings(right);

	state_log.push_back(0);  // asuming starting state is 0;
	
	while (right.size() > 0) {
	if (left.size() == 3 && left.at(2) == "EOF") {break;}
		struct rsrule rule;
		state_cur = state_log.back();
//~ cout << endl;
//~ cout << "left = ";
//~ print_strings(left);
//~ cout << "right = ";
//~ print_strings(right);

// cout << "At state " << state_cur << " see " << right.at(0) << endl;
		rule = this->next(state_cur, right.at(0));
		if (rule.kind == 0) {
// cout << "SHIFT" << endl;
			shift(&left, &right);
			state_log.push_back(rule.to);
			state_cur = rule.to;
		}
		
		else if (rule.kind == 1) {
// cout << "REDUCE" << endl;
			struct exrule ex;
			ex = get_ex(rule.to);
// cout << "The rule is " << ex.from << " ";
// print_strings(ex.to);

			int to_reduce = ex.to.size();
			

			while (to_reduce > 0) {
				left.pop_back();
				state_log.pop_back();
				to_reduce -= 1;
			}
			
			right.insert(right.begin(), ex.from);
			derivations.push_back(ex);
		}
		
		else if (rule.kind == 2) {
//~ cout << "REJECTED!!" << endl;
			return 42;
		}
	}
	// accept
//~ cout << "ACCEPTED!!" << endl;
	return 0;
}

struct rsrule LR1::next(int stateid, string t) {
	int size = rsrules.size();
	for (int i = 0; i < size; i++) {
// cout << "see rule: " << rsrules.at(i).from << " " << rsrules.at(i).middle << endl;
		if (stateid == rsrules.at(i).from && rsrules.at(i).middle == t) {
// cout << "FOUND use rule "
	// << rsrules.at(i).from << " "
	// << rsrules.at(i).middle << " "
	// << rsrules.at(i).kind << " "
	// << rsrules.at(i).to << endl;
			return rsrules.at(i);
		}
	}
	struct rsrule result;
	result.kind = ERROR;
	return result;
}

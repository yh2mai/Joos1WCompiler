public class thisinmethod{
	thisinmethod(){}
	public int m(){
	return super();	//A method or constructor must not contain explicit this() or super() calls.
	}
}
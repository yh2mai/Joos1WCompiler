import A.a;
public class Main extends a{
	public Main(){}
}
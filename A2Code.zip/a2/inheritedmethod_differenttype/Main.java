package A;
public class Main extends a implements b{
	public Main(){}
	public char m(){}
}
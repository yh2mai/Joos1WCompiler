import B.b;
public class A{
	A(){}
	public b m(){}
}
package A;
public interface simple2 {
}
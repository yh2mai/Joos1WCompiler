#include "regex.h"
#include "assert.h"
#include "sstream"
RegEx::RegEx(string s, string exp)
{
	type = s;
	isTerminal = 1;
	isComment = 0;
	//tokenize the exp
	/*e.g.
	a(a(abc)d)*c|d->a (a(abc)d)* c|d
	a(ab)|(abc) -> a (ab) | (abc)
	*/
	
	//temp string is to store the temperary string.
	string temp;
	//Star notation.
	int endStar = 0;
	//containor notation.
	int ContainOr = 0;
	if(s == "DECIMALINTEGER")
	{
		exps.push_back("DECIMAL");
	}
	else if(exp == "(string1 + string2)*")
	{
		exps.push_back("\"");
		exps.push_back("((string1)|(\\b|t|n|f|r|(\")|(\')|\\|([0-7])|([0-7][0-7])|([0-3][0-7][0-7])))*");
		exps.push_back("\"");
		isTerminal = 0;
	}
	else if (exp == "'(string2)|(string3)'")
	{
		exps.push_back("'");
		exps.push_back("(string2)|(\\b|t|n|f|r|(\")|(\')|\\|([0-7])|([0-7][0-7])|([0-3][0-7][0-7]))");
		exps.push_back("'");
		isTerminal = 0;
	}
	else if((exp == "|")|| (exp == "(" )|| (exp == "[")||( exp =="]")||(exp == "\"") ||(exp == "|=")||(exp == "^"))
	{
		exps.push_back(exp);
	}
	else if (exp == "||")
	{
		exps.push_back("||");
	}
	else
	{
		while(true)
		{	
			//capture the first character
			string t = exp.substr(0,1);
			//trim the exp
			exp=exp.substr(1);
			
			//UNION->MULTIPLEOR
			if(t == "\"" && ((type != "ESCAPESEQUENCE" && type != "STRINGVALUE" && type != "CHARVALUE")|| (exp.substr(0,3) == "b|t")))
			{
				ContainOr = 1;
				isTerminal = 0;
				exps.push_back("\"" + exp);
				break;
			}
			/* temp(abc) -|- ->temp(abc) |; */
			if(t == "|")
			{
				if(temp != "")
					exps.push_back(temp);
				exps.push_back("|");
				temp = "";
				ContainOr = 1;
				isTerminal = 0;
			}
			/* temp(abc) -a- ->temp(abca); */
			else if(t != "(")
			{
				temp = temp + t;
			}
			/* temp(abc) -(- ->push_back(temp) temp=( */
			else
			{
				if(temp != "")
					exps.push_back(temp);
				//since it meet a "(", it is not a terminal exp.
				isTerminal = 0;
				temp = t;
				//find the corresponding ")"
				int lbrnum = 0; //number of left bracket number (
				int rbrnum = 0; //number of right bracket number )
				while(true)
				{
					t = exp.substr(0,1);
					exp = exp.substr(1);
					if(t == ")")
					{
						if(lbrnum == rbrnum)
						{
						temp = temp + t;
							//check if there is a * after it.
							t = exp.substr(0,1);
							if( t == "*")
							{
								exp = exp.substr(1);
								temp = temp + t;
								exps.push_back(temp);
								temp = "";
								if(exp == "")
								{
									endStar = 1;
								}
							}
							else
							{
								exps.push_back(temp);
								temp = "";
							}
							break;
						}
						else
						{
							rbrnum = rbrnum + 1;
							temp = temp + t;
						}
					}
					else if(t == "(")
					{
						temp = temp + t;
						lbrnum = lbrnum + 1;
					}
					else
					{
						temp = temp + t;
					}
				}
			}
			if ( exp == "")
			{
				if(temp != "")
					exps.push_back(temp);
				break;
			}
		}
		//test exps after first tokenize
// vector<string>::iterator testexpsit;
// cout << "AFter tokenize exps size = " << exps.size() << endl;
// for(testexpsit = exps.begin(); testexpsit < exps.end(); testexpsit++)
// {
	// cout << *testexpsit << endl;
// }
		//handling multiple or situation.
		/* e.g. 
		After tokenize the string.kab|c|a, we got tokens kab | c | a.
		-> ka "b|c" | a ->ka "b|c|a"
		k (a)* | c | k -> k "(a)*|c" | k -> k "(a)*|c|k"
		*/
		vector<string> newexps;
		vector<string>::iterator expsit;
		for(expsit = exps.begin() + 1; expsit < exps.end(); expsit++)
		{
			if(*expsit == "|")
			{
				//get the last character of the exp before.
				stringstream ss;
				string lastcharacter;
				ss << *((*(expsit - 1)).end() - 1);
				ss >> lastcharacter;
				
				//get the second last character of the exp before.
				stringstream ss1;
				string secondlastcharacter;
				ss1 << *((*(expsit - 1)).end() - 2);
				ss1 >> secondlastcharacter;
				
				//get the first character of the exp after.
				string firstcharacter =  (*(expsit + 1)).substr(0,1);
				// cout << "firstcharacter = " << firstcharacter << endl;
				string addtolastexp = "";
				//handling the next exp and save the string needed to added to the last exp.
				if( firstcharacter == "(" )
					{
						addtolastexp = addtolastexp + ("|" + *(expsit + 1) + "\"");
						exps.erase(expsit,expsit + 1);
					}
				else if (firstcharacter == "^")
				{
					addtolastexp = addtolastexp + ("|" + (*(expsit + 1)).substr(0,2) + "\"");
					(*(expsit + 1)).erase(0, 2);
					if(*(expsit + 1) == "")
						exps.erase(expsit + 1);
				}
				else if (firstcharacter == "[")
				{
					addtolastexp = addtolastexp + ("|" + (*(expsit + 1)).substr(0,5) +"\"");
					(*(expsit + 1)).erase(0,5);
					if(*(expsit + 1) == "")
					{
						exps.erase(expsit + 1);
					}
				}
				else
				{
					addtolastexp+=("|" + (*(expsit + 1)).substr(0,1) + "\"");
					(*(expsit + 1)).erase(0, 1);
					if(*(expsit + 1) == "")
						exps.erase(expsit + 1);
				}
// cout << "firstcharacter = " << firstcharacter << " addtolastexp = " << addtolastexp << endl;
				//handling last exp
				if ( lastcharacter == ")")
				{
					(*(expsit - 1)) = "\"" + *(expsit - 1) + (addtolastexp);
	// cout << "expsit -1=  " << *(expsit - 1) << endl; 			
					exps.erase(expsit);
					expsit--;
				}
				else if ( lastcharacter == "\"" )
				{

					(*(expsit - 1)).erase((*(expsit - 1)).end() - 1);
					(*(expsit - 1))+=(addtolastexp);
// cout << "IN LASTCHARACTER = \" expsit - 1 = " << *(expsit - 1) << endl;
					exps.erase(expsit);
					expsit--;
				}
				else if ( lastcharacter == "*")
				{
					(*(expsit - 1)) = "\"" + (*(expsit - 1));
					(*(expsit - 1))+=(addtolastexp + "\"");
					exps.erase(expsit);
					expsit--;
				}
				else if (lastcharacter == "]")
				{
					int length = (*(expsit - 1)).size();
					string temps = (*(expsit - 1)).substr(length - 5);
					*expsit = "\"" + temps + addtolastexp;
					(*(expsit - 1)).erase((*(expsit - 1)).end() - 5,(*(expsit - 1)).end());
					if(*(expsit - 1) == "")
					{
						exps.erase(expsit - 1, expsit);
						expsit--;
					}
				}
				else if (secondlastcharacter == "^")
				{
					int length = (*(expsit - 1)).size();
					string temps = (*(expsit - 1)).substr(length - 2);
					*expsit = "\"" + temps + addtolastexp;
					(*(expsit - 1)).erase((*(expsit - 1)).end() - 2,(*(expsit - 1)).end());
					if(*(expsit - 1) == "")
					{
						exps.erase(expsit - 1, expsit);
						expsit--;
					}
				}
				else
				{
					stringstream tempss;
					string temps;
					tempss << *((*(expsit - 1)).end() - 1);
					tempss >> temps;
					*expsit = "\"" + temps + addtolastexp;
// cout << "expsit = " << *expsit << endl;
					(*(expsit - 1)).erase((*(expsit - 1)).end() - 1);
					if(*(expsit - 1) == "")
					{
						exps.erase(expsit - 1, expsit);
						expsit--;
					}
				}
			}
		}
		//test exps after first tokenize
// cout << "After handling multipleor exps size = " << exps.size() << endl;
// for(testexpsit = exps.begin(); testexpsit < exps.end(); testexpsit++)
// {
	// cout << *testexpsit << endl;
// }
	}
	//Determine rule
	if(isTerminal)
		rule = TERMINAL;
	else if (ContainOr && (exps.size() == 1))
		rule = MULTIPLEOR;
	else if(endStar && (exps.size() == 1) && !ContainOr)
		rule = STAR;
	else 
		rule = UNION;
}

vector<string> RegEx::getexps()
{
	return exps;
}


void RegEx::changeisComment()
{
	isComment = 1;
}
NFA RegEx::convertToNFA(){
	if(exps.size() == 1 && exps.at(0) == "DECIMAL")
	{
		NFA retNFA = NFA::NFA();
		vector<string> alphs;
		string myalphs[] = {"0","1","2","3","4","5","6","7","8","9"};
		alphs.assign(myalphs, myalphs + sizeof(myalphs)/ sizeof(string));
		vector<struct NState> state = retNFA.getstates();
		struct NState newstate;
		newstate.id = 1;
		newstate.kind = "DECIMALINTEGER";
		newstate.isEnd = 1;
		state.push_back(newstate);
		struct NState newstate1;
		newstate1.id = 2;
		newstate1.kind = "DECIMALINTEGER";
		newstate1.isEnd = 1;
		state.push_back(newstate1);
		retNFA.num_alph = 10;
		retNFA.num_state = 3;
		retNFA.setstates(state);
		vector<struct NState> terminal = retNFA.getterminals();
		terminal.push_back(newstate);
		terminal.push_back(newstate1);
		retNFA.setterminals(terminal);
		vector<struct Transition> trans;	
		struct Transition newtrans = retNFA.transitionmaker(state.at(0),state.at(1),"0");
		trans.push_back(newtrans);		
		for(int i = 0; i < alphs.size() ; i++)
		{			
			struct Transition newtrans1 = retNFA.transitionmaker(state.at(2),state.at(2),alphs.at(i));
			trans.push_back(newtrans1);
		}
		for(int i = 1; i < alphs.size() ; i++)
		{
			struct Transition newtrans = retNFA.transitionmaker(state.at(0),state.at(2),alphs.at(i));
			trans.push_back(newtrans);
		}
		retNFA.settrans(trans);
		return retNFA;
	}
// THIS IS A BUG FIXER FOR | ( ) [ ] " SYMBOL
	else if(exps.size() == 1 && (exps.at(0) == "|" || exps.at(0) == "(" || exps.at(0) == ")" || exps.at(0) == "[" || exps.at(0) == "]"|| exps.at(0) == "\"" || (type == "STRINGVALUE" && exps.at(0) == "string1")) || (type == "CHARVALUE" && exps.at(0) == "string2") || exps.at(0) == "^" )
	{
// cout <<"BUG FIXER 1" << endl;
		NFA retNFA = NFA::NFA();
		vector<string> alphs;
		if(exps.at(0) == "string1")
			exps.at(0) = "^\"\\";
		if(exps.at(0) == "string2")
			exps.at(0) = "^'\\";
		alphs.push_back(exps.at(0));
		retNFA.setalphs(alphs);
		vector<struct NState> state = retNFA.getstates();
		struct NState newstate;
		newstate.id = 1;
		if(exps.at(0) == "|")
		newstate.kind = "EAGER_OR";
		else if (exps.at(0) == "(")
		newstate.kind = "ROUNDBRACKET_L";
		else if (exps.at(0) == ")")
		newstate.kind = "ROUNDBRACKET_R";
		else if (exps.at(0) == "[")
		newstate.kind = "SQUAREBRACKET_L";
		else if (exps.at(0) == "]")
		newstate.kind = "SQUAREBRACKET_R";
		else if (exps.at(0) == "\"" && type == "ESCAPESEQUENCE")
		newstate.kind = "ESCAPESEQUENCE";
		else if (exps.at(0) == "\"" && type == "STRINGVALUE")
		newstate.kind = "STRINGVALUE";
		else if (exps.at(0) == "^\"\\")
		newstate.kind = "STRINGVALUE";
		else if (exps.at(0) == "^'\\")
		newstate.kind = "CHARVALUE";
		else
		newstate.kind = "ERROR_OPERATORS";
		newstate.isEnd = 1;
		state.push_back(newstate);
		retNFA.setstates(state);
		vector<struct NState> terminal;
		terminal.push_back(newstate);
		retNFA.setterminals(terminal);
		retNFA.num_alph = 1;
		retNFA.num_state = 2;
		vector<struct Transition> trans;
		struct Transition newtrans = retNFA.transitionmaker(state.at(0),state.at(1),exps.at(0));
		trans.push_back(newtrans);
		retNFA.settrans(trans);
		return retNFA;
	}
// THIS IS A BUG FIXER FOR "||" SYMBOL
	else if(exps.size() == 1 && (exps.at(0) == "||" || exps.at(0) =="^="))
		{
// cout << "BUG FIXER 2 " << endl;
			NFA retNFA = NFA::NFA();
			vector<string> alphs;
			if(exps.at(0) == "||")
				alphs.push_back("|");
			else
			{
				alphs.push_back("^");
				alphs.push_back("=");
			}
			retNFA.setalphs(alphs);
			vector<struct NState> state = retNFA.getstates();
			struct NState newstate;
			newstate.id = 1;
			newstate.kind = "";
			newstate.isEnd = 0;
			state.push_back(newstate);
			struct NState newstate1;
			newstate1.id = 2;
			if(exps.at(0) == "||")
				newstate1.kind = "OR";
			else
				newstate1.kind = "ERROR_OPERATORS";
			newstate1.isEnd = 1;
			state.push_back(newstate1);
			retNFA.setstates(state);
			vector<struct NState> terminal;
			terminal.push_back(newstate1);
			retNFA.setterminals(terminal);
			retNFA.num_alph = 1;
			retNFA.num_state = 3;
			vector<struct Transition> trans;
			struct Transition newtrans;
			if(exps.at(0) == "||")
				newtrans = retNFA.transitionmaker(state.at(0),state.at(1),"|");
			else 
				newtrans = retNFA.transitionmaker(state.at(0),state.at(1),"^");
			trans.push_back(newtrans);
			struct Transition newtrans1;
			if(exps.at(0) == "||")
				newtrans1 = retNFA.transitionmaker(state.at(1),state.at(2),"|");
			else
				newtrans1 = retNFA.transitionmaker(state.at(1),state.at(2),"=");
			trans.push_back(newtrans1);
			retNFA.settrans(trans);
			return retNFA;
		}
	else if(isTerminal)
	{
// cout << "Enter terminal Terminal string = " << exps.at(0) << endl;
		NFA retNFA = NFA::NFA();
		//It must have only one token.
		assert(exps.size() == 1);
		//capture the string
		string t = exps.at(0);
		
		//get all information of the NFA
		vector<string> alphs = retNFA.getalphs();
		vector<struct NState> states = retNFA.getstates();
		vector<struct NState> terminals = retNFA.getterminals();
// cout << "after initializing terminal size = " << terminals.size() << endl;
		vector<struct Transition> trans = retNFA.gettrans();
		
		
		struct NState terminal;
		int terminalcreate = 0;
		
		//capture the first state
		struct NState oldstate = states.at(0);
		
		//last character
		string lastc = "";
		
		//special case for comment
		if( t == "*" && isComment)
		{
			alphs.push_back("^*/");
			retNFA.num_alph += 1;
			struct NState specialstate;
			specialstate.id = 0;
			specialstate.kind = "";
			specialstate.isEnd = 0;
			struct NState specialstate2;
			specialstate2.id = 1;
			specialstate.kind = "COMMENT";
			specialstate.isEnd = 1;
			struct Transition specialtrans = retNFA.transitionmaker(specialstate2,specialstate,"^*/");
			trans.push_back(specialtrans);
		}
		
		//Range's final state created.
		int rangefinalstatecreated = 0;
		//iterate through the characters in the string
		while(true)
		{
// cout <<" lastc = " << lastc << endl;
			//the first character in the string.
			/* e.g. a [a-b] ^a*/
			//indicator isRange
			int isRange = 0;
			string c = t.substr(0,1);
			string rangestr = "";
			if(c == "[")
			{
				c = t.substr(1,1);
				rangestr = t.substr(0,5);
				t = t.substr(5);
// cout <<"rangestr = " << rangestr << " c = " << c << "  t = " << t << endl;
				isRange = 1;
			}
			else if ( c == "^" )
			{
				c = c + t.substr(1,1);
				t = t.substr(2);
			}
			else
			{
				t = t.substr(1);
			}
			//check whther it is already in the alphs
			vector<string>::iterator it;
			int isInalphs = 0;
			for(it = alphs.begin(); it < alphs.end(); it++)
			{
				if( *it == c) 
				{
					isInalphs = 1;
				}
			}
			if(!isInalphs)
			{
				retNFA.num_alph += 1;
				alphs.push_back(c);
			}
			
			
			//update the transition and states
			struct NState tstate;	
			if(!isRange || (isRange && !rangefinalstatecreated))
				tstate.id = retNFA.num_state;	
			else 
				tstate.id = retNFA.num_state - 1;
			if(!isRange ||(isRange && !rangefinalstatecreated))
			{
				retNFA.num_state = retNFA.num_state + 1;
			}
			
			if(t == "")
			{	
				if(!terminalcreate)
				{	
					terminal.id = retNFA.num_state - 1;
					terminal.isEnd = 1;
					terminal.kind = type;
					states.push_back(terminal);
					terminals.push_back(terminal);
					terminalcreate = 1;
				}
				else if(!isRange ||(isRange && !rangefinalstatecreated))
					retNFA.num_state = retNFA.num_state - 1;
				struct Transition newtrans = retNFA.transitionmaker( oldstate, terminal, c);
				trans.push_back(newtrans);
			}
			else
			{	
				tstate.isEnd = 0;
				tstate.kind = "";
				if(!isRange || (isRange && !rangefinalstatecreated))
				{
					states.push_back(tstate);
					rangefinalstatecreated = 1;
				}
				struct Transition newtrans = retNFA.transitionmaker( oldstate, tstate, c);
				trans.push_back(newtrans);
			}
			if(!isRange)
			{
				if(t == "")
					break;
				else
				oldstate = tstate;
			}
			else
			{
				if(rangestr.at(1) == rangestr.at(3))
				{
					if(t == "")
						break;
					else
					{
						rangefinalstatecreated = 0;
						oldstate = tstate;
						continue;
					}
				}
				rangestr.at(1) = (char) (c.at(0) + 1);
				t = rangestr + t;
			}	
		}
		retNFA.setalphs(alphs);
		retNFA.setstates(states);
		retNFA.setterminals(terminals);
		retNFA.settrans(trans);
		return retNFA;
	}
	else if (rule == STAR)
	{
// cout << "STAR, exps.at(0) = " << exps.at(0) << endl;
		NFA retNFA;
		//It must have only one token.
		assert(exps.size() == 1);
		//capture the string
		string t = exps.at(0);
		//trim the string  e.g.(ab)*->ab
		t = t.substr(1,t.size()-3);
		RegEx newReg = RegEx(type, t);
		retNFA = newReg.convertToNFA();


		//get the terminal state
		vector<struct NState> terminal = retNFA.getterminals();
		assert(terminal.size() == 1);
		
		//set the start state to be Endable
		vector<struct NState> states = retNFA.getstates();
		states.at(0).isEnd = 1;
		states.at(0).kind = terminal.at(0).kind;
		
		//modify the NFA
		/*
		*/
		vector<struct Transition> origtrans = retNFA.gettrans();
		vector<struct Transition> trans = retNFA.gettrans();
		vector<struct Transition>::iterator transitionit;
		//set the transition's end state to the start state
		for(transitionit = origtrans.begin(); transitionit < origtrans.end(); transitionit++)
		{
			if((*transitionit).to.id == terminal.at(0).id ||((*transitionit).to.id == 0))
			{
				(*transitionit).to = states.at(0);
			}
			if((*transitionit).from.id == terminal.at(0).id || ((*transitionit).from.id == 0))
				(*transitionit).from = states.at(0);
			if((*transitionit).to.id > terminal.at(0).id)
				(*transitionit).to.id --;
			if((*transitionit).from.id > terminal.at(0).id)
				(*transitionit).from.id --;
		}
		
		//modify the terminal state and states
		vector<struct NState>::iterator statesit;
		for(statesit = states.begin() + 1; statesit < states.end(); statesit++)
		{
			if((*statesit).id > terminal.at(0).id)
				(*statesit).id --;
			else if((*statesit).id == terminal.at(0).id)
			{
				states.erase(statesit);
				retNFA.num_state--;
				statesit -= 1;
			}
		}
		
		terminal.pop_back();
		terminal.push_back(states.at(0));
		retNFA.setterminals(terminal);
		retNFA.settrans(origtrans);
		retNFA.setstates(states);

		return retNFA;
	}
	else if (rule == MULTIPLEOR)
	{
// cout << "MULTIPLEOR, exps.at(0) = " << exps.at(0) << endl;
		/*idea:
		make one NFA, modify the NFA for each OR expression
		*/
		string temp = "";
		NFA retNFA;
		string exp = exps.at(0);
		exp = exp.substr(1,exp.size() - 2);
		int lbrnum = 0;
		int rbrnum = 0;
		while(true)
		{
			//capture the first character
			string c = exp.substr(0,1);
			exp = exp.substr(1);
			if( c == "(")
			{
				lbrnum += 1;
				temp += c;
			}
			else if (c == ")")
			{
				rbrnum += 1;
				temp += c;
			}
			else if(c == "|" && lbrnum == rbrnum)
			{
				break;
			}
			else
			{
				temp += c;
			}
		}
		int len = temp.size();
		if(temp.substr(0,1) =="(" && temp.substr(len - 1,1) == ")")
			temp = temp.substr(1, len - 2);
// cout << "temp = " << temp << endl;
		RegEx RE(type, temp);
		temp = "";
		lbrnum = 0;
		rbrnum = 0;
		retNFA = RE.convertToNFA();
		while(true)
		{
			//capture the first character
			string c = exp.substr(0,1);
			// if (c == "")
				// break;
			exp = exp.substr(1);
// cout << "c = " << c << "exp = " << exp << endl;
			if( c == "(")
			{
				lbrnum += 1;
				temp += c;
			}
			else if (c == ")"&&(exp != ""))
			{
				rbrnum += 1;
				temp += c;
			}
			else if((c == "|" && lbrnum == rbrnum)||(exp.size() == 0))
			{
				if(exp == "")
					temp = temp + c;
// cout << "temp.size() = " << temp.size() << endl;
				int len = temp.size();
				if(temp.substr(0,1) =="(" && temp.substr(len - 1,1) == ")")
					temp = temp.substr(1, len - 2);
// cout << "temp = " << temp << endl;
				RegEx tempRE(type, temp);
				temp = "";
				lbrnum = 0;
				rbrnum = 0;
				//modify the old NFA, get the information of the newly created NFA.
				NFA tempNFA = tempRE.convertToNFA();
				vector<string> tempalphs = tempNFA.getalphs();
				vector<struct NState> tempstates = tempNFA.getstates();
				vector<struct NState> tempterminals = tempNFA.getterminals();
				vector<struct Transition> temptrans = tempNFA.gettrans();
				int InAlphs = 0;
				//modified alphs and num_alph
				vector<string>::iterator alphsit,oldalphsit;
				vector<string> tempold = retNFA.getalphs();
				vector<string> newalphs = retNFA.getalphs();
				for(alphsit = tempalphs.begin(); alphsit < tempalphs.end(); alphsit++)
				{
					for(oldalphsit = tempold.begin();oldalphsit < tempold.end(); oldalphsit++)
					{
						if( *alphsit == *oldalphsit)
						{
							InAlphs = 1;
						}
					}
					if(!InAlphs)
					{
						retNFA.num_alph++;
						newalphs.push_back(*alphsit);
					}
					else
						InAlphs = 0;
				}
				retNFA.setalphs(newalphs);
				
				//modify states , num_state and terminals
				vector<struct NState>::iterator statesit;
				vector<struct NState> newstates = retNFA.getstates();
				struct NState newterm = tempNFA.getterminals().at(0);
				//save the num_state
				int oldnum_state = retNFA.num_state;
				for(statesit = tempstates.begin() + 1;statesit < tempstates.end(); statesit ++)
				{
					if((*statesit).isEnd == 0)
					{
					//modify id of the new state by adding oldnum_state
						if((*statesit).id > newterm.id)
							(*statesit).id -= 1;
						(*statesit).id += (oldnum_state - 1);
						newstates.push_back(*statesit);
						retNFA.num_state += 1;
					}
				}
				retNFA.setstates(newstates);
				
				//modify transitions
				vector<struct Transition> newtrans = retNFA.gettrans();
				vector<struct Transition>::iterator transit;
				for(transit = temptrans.begin(); transit < temptrans.end(); transit++)
				{
					assert(retNFA.getterminals().size() == 1);
					if((*transit).from.id != 0)
					{
						if((*transit).from.id > newterm.id)
							(*transit).from.id -= 1;
						(*transit).from.id += (oldnum_state - 1);
					}
					if((*transit).to.id != 0)
					{
						if((*transit).to.id > newterm.id)
							(*transit).to.id -= 1;
						(*transit).to.id += (oldnum_state - 1);
					}
					if((*transit).from.isEnd == 1)
					{
						(*transit).from = retNFA.getterminals().at(0);
					}
					if((*transit).to.isEnd == 1)
					{
						(*transit).to = retNFA.getterminals().at(0);
					}
					newtrans.push_back(*transit);
				}
				retNFA.settrans(newtrans);
				if ( exp != "")
				{
					continue;
				}
				else
				{
					return retNFA;
					break;
				}
			}
			else
			{
				temp += c;
			}
		}
// cout << "end multipleor" << endl;
	}
	else   //UNION
	{
		vector<string>::iterator expit;
		NFA retNFA;
// cout << "UNION, exps.at(0) = " << exps.at(0) << endl;
		for(expit = exps.begin();expit < exps.end(); expit++)
		{
			//transfer the exp into NFA.
// cout << *expit << endl;
			RegEx tempRegEx = RegEx(type, *expit);
			if(*expit == "*")
				tempRegEx.changeisComment();
			NFA tempNFA = tempRegEx.convertToNFA();
			if(retNFA.getterminals().size() == 0)
			{
				//first NFA
// cout << "FIRST NFA" << endl;
				retNFA = tempNFA;
			}
			else
			{
				//modify retNFA
				//modify alphs and num_alphs
				int InAlphs = 0;
				//modified alphs and num_alph
				vector<string>::iterator alphsit,oldalphsit;
				vector<string> tempold = retNFA.getalphs();
				vector<string> newalphs = retNFA.getalphs();
				vector<string> tempalphs = tempNFA.getalphs();
				for(alphsit = tempalphs.begin(); alphsit < tempalphs.end(); alphsit++)
				{
					InAlphs = 0;
					for(oldalphsit = tempold.begin();oldalphsit < tempold.end(); oldalphsit++)
					{
						if( *alphsit == *oldalphsit)
						{
							InAlphs = 1;
							break;
						}
					}
					if(!InAlphs)
					{
						retNFA.num_alph++;
						newalphs.push_back(*alphsit);
					}
				}
				retNFA.setalphs(newalphs);
				
				//modify the states and terminals, num_state
				vector<struct NState>::iterator statesit;
				vector<struct NState> newstates = retNFA.getstates();
				vector<struct NState> tempstates = tempNFA.getstates();
assert(retNFA.getterminals().size() == 1);
				struct NState oldterminal = retNFA.getterminals().at(0);
				vector<struct NState> newterminal;
				// changed by Jason
				// newterminal.push_back(tempNFA.getterminals().at(0));
						
				//save the num_state
				int oldnum_state = retNFA.num_state;
				
				
				
				//mark the terminal state of the old NFA unterminal.
				for(statesit = newstates.begin(); statesit < newstates.end();statesit++)
				{
				
					if((*statesit).isEnd == 1)
					{
					//special case for STAR 
						if(tempRegEx.getrule() != STAR )
						{
							(*statesit).isEnd = 0;
							(*statesit).kind = "";
						}
					}
				}
				
				if (tempRegEx.getrule() == STAR )
					newterminal.push_back(retNFA.getterminals().at(0));
				
				//add new states from the new NFA
				for(statesit = tempstates.begin() + 1;statesit < tempstates.end(); statesit ++)
				{
				//modify id of the new state by adding oldnum_state
					(*statesit).id += (oldnum_state - 1);
					newstates.push_back(*statesit);
					retNFA.num_state += 1;
					if((*statesit).isEnd == 1 && tempRegEx.getrule() != STAR )
						newterminal.push_back(*statesit);
				}
				
				retNFA.setstates(newstates);
				
				//modify transition
				vector<struct Transition> oldtrans = retNFA.gettrans();
// cout << "OLD TRANS size = " << oldtrans.size() << endl;
				vector<struct Transition> newtrans = tempNFA.gettrans();
// cout << "new TRANS size = " << newtrans.size() << endl;
				vector<struct Transition>::iterator transit;
				//modify the old transition

				for(transit = oldtrans.begin(); transit < oldtrans.end(); transit++)
				{
					if(tempRegEx.getrule() != STAR)
					{
						if((*transit).from.isEnd == 1)
						{
							(*transit).from.isEnd = 0;
							(*transit).from.kind = "";
						}
						if((*transit).to.isEnd == 1)
						{
							(*transit).to.isEnd = 0;
							(*transit).to.kind = "";
						}
					}
					else
					{
						if((*transit).from.isEnd ==1 )
						{
							(*transit).from.kind = tempNFA.getterminals().at(0).kind;
						}
						if((*transit).to.isEnd == 1 )
						{
							(*transit).to.kind = tempNFA.getterminals().at(0).kind;
						}
					}
				}
				if(tempRegEx.getrule() == STAR)
				{
// cout << "Enter UNION, tempRegEx is STAR " << endl;
					for(transit = newtrans.begin();transit< newtrans.end();transit++)
					{
						if((*transit).from.id == 0)
							(*transit).from = oldterminal;	
						else
							(*transit).from.id += (oldnum_state - 1);
						if((*transit).to.id == 0)
							(*transit).to = oldterminal;
						else
							(*transit).to.id += (oldnum_state - 1);
						oldtrans.push_back(*transit);
					}
				}
				else
				{
					for(transit = newtrans.begin();transit < newtrans.end();transit++)
					{
						if((*transit).from.isEnd == 0)
							(*transit).from.kind = "";
						if((*transit).to.isEnd == 0)
							(*transit).to.kind = "";
// cout << "oldnum_state = " << oldnum_state << endl;
						if((*transit).from.id == 0)
							(*transit).from.id = oldterminal.id;
						else
							(*transit).from.id += (oldnum_state - 1);
						if((*transit).to.id == 0)
							(*transit).to.id = oldterminal.id;
						else
							(*transit).to.id += (oldnum_state - 1);
						oldtrans.push_back(*transit);
					}
				}
				retNFA.settrans(oldtrans);
				
				//set the terminals
				retNFA.setterminals(newterminal);
			}
		}
		return retNFA;
	}
}

Rule RegEx::getrule(){
	return rule;
}

// int main()
// {
	// RegEx testReg = RegEx("test", "a|b|c|d");
	// vector<string> exps = testReg.getexps();
	// vector<string>::iterator expsit;
	// for(expsit = exps.begin(); expsit < exps.end(); expsit++)
	// {
		// cout << *expsit << endl;
	// }
	// NFA testNFA = testReg.convertToNFA();
	// cout << "Rule = " <<testReg.getrule() << endl;
	
	// return 0;
// }

	

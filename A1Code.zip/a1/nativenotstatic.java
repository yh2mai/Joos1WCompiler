public class nativenotstatic{
	native int m(){}//A native method must be static.
}
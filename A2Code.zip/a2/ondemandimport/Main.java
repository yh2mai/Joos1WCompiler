import A.*;
public class Main
{
	public Main(){}
	public String m(){}
}
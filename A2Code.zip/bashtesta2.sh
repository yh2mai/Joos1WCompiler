#!/bin/bash
rm testout
for file in a2/*; do
	echo "file: $file"
	./joosc `find -L $file -name '*.java'` `find -L stdlib/ -name '*.java'`
	echo "$file: $?" >> testout
done
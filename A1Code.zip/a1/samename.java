// public class asamename{//A class/interface must be declared in a .java file with the same base name as the class/interface.
	
// }

public interface asamename{//A class/interface must be declared in a .java file with the same base name as the class/interface.
	
}
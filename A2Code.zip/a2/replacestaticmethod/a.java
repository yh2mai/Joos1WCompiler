package A;
public class a extends b{
	public a(){}
	public int m(){}		//replace the static methods should return 42
}
public class duplicatefield{
	duplicatefield(){}
	public int a = 1;
	public int a = 2;	//Duplicated fields
}
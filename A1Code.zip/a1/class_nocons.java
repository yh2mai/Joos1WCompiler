public class class_nocons{//Every class must contain at least one explicit constructor.
	public int m(){}
}
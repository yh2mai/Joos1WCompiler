#include "DFA.h"
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>
#include "../parser/lr1.h"

using namespace std;

int StringToInt(string s) {
	return atoi(s.c_str());
}

DFA::DFA() {
	state_ctr = 0;
	start = 0;
}

struct DState DFA::get_state(int k) {
  return states.at(k);
}

int DFA::reach(int current, string a){
	int max = trans.size();
	vector<string> list;
	
	
	for (int i=0; i<max; i++) {
		if (current == trans.at(i).from.id){
			if (trans.at(i).t.size() == 1)
			{
				if(trans.at(i).t == a) 
				{
					return trans.at(i).to.id;
				}
			}
			else
			{
				string k = trans.at(i).t.substr(1);
				int isIn = 0;
				for(int j = 0 ; j < k.size(); j++)
				{
					if(k.substr(j,1) == a)
						isIn = 1;
				}
				if(!isIn)
					return trans.at(i).to.id;
			}
		}
	}
	//cannot reach any valid state.
	return -1;
}


DState::DState(int idd, string kinds, int is, vector<int> idds) {
	id = idd;
	kind = kinds;
	isTerminal = is;
	ids = idds;
}

DTransition::DTransition(DState f, DState tt, string m) {
	from = f;
	to = tt;
	t = m;
}

// read DFA from file
DFA::DFA(string file) {
	state_ctr = 0;
	start = 0;
	
	string line;
  ifstream dfafile (file);
	if (!dfafile) {
		cout << "Unable to open file" << file << endl; 
		dfafile.close();
		exit(1);
	}

	else if( dfafile.is_open() ) {
		// debug
		// cout << "open success" << endl;
		char x;

		while(1) {
			string alpha;
			do {
				x = dfafile.get();

			} while (x != '$' && x != '\n');
			
			if (x == '\n') { break; }
			x = dfafile.get();
			
			while (x != '$') {
				// cout << "got " << x << endl;
				alpha += (string)&x;
				x = dfafile.get();
			} 

			alphs.push_back(alpha);
			alpha = "";
			// push the string to alphas
		
		}
		x = dfafile.get(); // newline char
		
		while (1) {
			string id, kind, terminal, ids, nothing;
			vector<string> idss;
			vector<int> idnum;
			
			
			getline(dfafile, id);
			if (id.length() < 1) {
				break;
			}
			getline(dfafile, kind);
			getline(dfafile, terminal);
			getline(dfafile, ids);
			
			
			idss = str_tokenize(ids);
			for (int i = 1; i < idss.size(); i++) {
				idnum.push_back(StringToInt(idss.at(i)));
			}
			idnum.resize(idnum.size()-1);
			
			int f_id = StringToInt(str_tokenize(id).at(1));
			int f_term = StringToInt(str_tokenize(terminal).at(1));
			string f_kind = str_tokenize(kind).at(1);
						
			struct DState d = DState(f_id, f_kind, f_term, idnum);
			// print_dstate(d);
			states.push_back(d);
			
			getline(dfafile, nothing);
			// make a new state, push state
		}
		
		while (1) {
			char a;
			string s1, s2;
			string line = "";
			
			dfafile >> s1;
			if (s1.length() < 1) {
				break;
			}
// cout << "s1[" << s1 << "]";
			dfafile.get();// space
			dfafile.get();// $
			
			a = dfafile.get();
			while (a != '$') {
// cout << "a[" << a << "] ";
				line += (string)&a;
				a = dfafile.get();
			} 
			
			dfafile.get();// space
			
			dfafile >> s2;
// cout << "s2[" << s2 << "]" << endl;
			dfafile.get();// newline
			
			int from, to;
			from = StringToInt(s1);
			to = StringToInt(s2);
			struct DTransition dt = DTransition(states.at(from), states.at(to), line);
			trans.push_back(dt);
			// cout << dt.from.id << "[" << dt.t << "]" << dt.to.id << endl;
			line = "";
			
			
			// save this to transition
		}
		
	}
	dfafile.close();
}
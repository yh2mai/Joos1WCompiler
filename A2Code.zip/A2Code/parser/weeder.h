#ifndef __WEEDER_H__
#define __WEEDER_H__

#include "parsetree.h"
#include <string>
#include <vector>

int weeder(parsetree* pt);
int weeder_classdeclaration(parsetree* pt);
int weeder_methoddecl(parsetree * pt);
int weeder_name(parsetree* pt, string filename);
int in_interface(parsetree* pt);
int weeder_abstractmethoddecl(parsetree* pt);
int weeder_fielddecl(parsetree* pt);
int weeder_cast(parsetree* pt);
int inRange(vector<string> numbers);
#endif
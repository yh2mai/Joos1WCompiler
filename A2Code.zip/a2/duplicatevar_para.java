public class duplicatevar_para{
	duplicatevar_para(int a){int a = 1;}//duplicatevariable with parameter
}
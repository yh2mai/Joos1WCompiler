public class abstractmethod_staticfinal{	//42
	abstract final int m(){}
}
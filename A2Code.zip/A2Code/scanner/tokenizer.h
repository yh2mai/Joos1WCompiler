#ifndef __TOKENIZER_H__
#define __TOKENIZER_H__

#include <string>
#include <vector>
#include "token.h"

//std::string DFA::getstatestring(int id);
std::vector<Token> tokenizer(DFA d, std::string line, int *a);



#endif
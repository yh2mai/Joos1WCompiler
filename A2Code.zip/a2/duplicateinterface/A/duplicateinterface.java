public interface duplicateinterface{
}
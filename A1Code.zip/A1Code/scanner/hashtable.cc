#include "hashtable.h"
using namespace std;

unordered_map<string, int>kind_priority_hash(){
	unordered_map<string, int> ret;
	// LINETERMINATOR
	ret["LINETERMINATOR"] = 1;
	// SPACE
	ret["SPACE"] = 2;
	// COMMENT
	ret["COMMENT"] = 3;
	// ERRORONEOUS KEYWORD
	ret["ERROR_KEYWORDS"] = 4;
	// KEYWORD
	ret["ABSTRACT"] = 5;
	ret["ASSERT"] = 5;
	ret["BOOLEAN"] = 5;
	ret["BYTE"] = 5;
	ret["CHAR"] = 5;
	ret["CLASS"] = 5;
	ret["CONST"] =5;
	ret["ELSE"] =5;
	ret["ENUM"] = 5;
	ret["EXTENDS"] =5;
	ret["FINAL"] = 5;
	ret["FOR"] = 5;
	ret["IF"] = 5;
	ret["IMPLEMENTS"] = 5;
	ret["IMPORT"] = 5;
	ret["INSTANCEOF"] = 5;
	ret["INT"] = 5;
	ret["INTERFACE"] = 5;
	ret["NATIVE"] = 5;
	ret["NEW"] = 5;
	ret["PACKAGE"] = 5;
	ret["PROTECTED"] = 5;
	ret["PUBLIC"] = 5;
	ret["RETURN"] = 5;
	ret["SHORT"] = 5;
	ret["STATIC"] = 5;
	ret["SUPER"] = 5;
	ret["THIS"] = 5;
	ret["VOID"] = 5;
	ret["WHILE"] = 5;
	
	//ERRORONEOUS OPERATOR
	ret["ERROR_OPERATORS"] = 6;
	
	// LEGAL OPERATORS
	ret["PLUS"] = 7;
	ret["MINUS"] = 7;
	ret["DIV"] = 7;
	ret["MOD"] = 7;
	ret["MUL"] = 7;
	ret["LESS_EQ"] =7;
	ret["MORE_EQ"] = 7;
	ret["LESS"] = 7;
	ret["MORE"] = 7;
	ret["NOT_EQ"] = 7;
	ret["NOT"] = 7;
	ret["AND"] = 7;
	ret["EAGER_AND"] = 7;
	ret["OR"] = 7;
	ret["EAGER_OR"] = 7;
	ret["EQUAL"] =7;
	ret["ASSIGN"] = 7;
	
	// SEPERATOR
	ret["ROUNDBRACKET_L"] = 8;
	ret["ROUNDBRACKET_R"] = 8;
	ret["SQUAREBRACKET_L"] =8;
	ret["SQUAREBRACKET_R"] = 8;
	ret["CURLYBRACKET_L"] = 8;
	ret["CURLYBRACKET_R"] = 8;
	ret["SEMILYCOLON"] = 8;
	ret["COLON"] = 8;
	ret["COMMA"] = 8;
	ret["DOT"] =8;
	
	// NULL
	ret["NULL"] =9;
	
	//String literal
	ret["STRINGVALUE"] =10;
	
	// Char literal
	ret["CHARVALUE"] = 11;
	
	// DECIMAL INTEGER
	ret["DECIMALINTEGER"] = 12;
	
	// HEXINTEGER
	ret["HEXINTEGER"] = 13;
	
	// OCTINTEGER
	ret["OCTINTEGER"] =14;
	
	// BOOLEAN LITERAL
	ret["BOOLVALUE"] =15;
	
	//ID
	ret["ID"] = 16;
	
	// LABEL
	ret["LABEL"] = 17;
	
	return ret;
}
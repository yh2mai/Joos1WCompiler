#include "link_type.h"
#include "../environment/scope.h"
#include <vector>
#include <string>
#include <stack>
#include <iostream>
#define DEBUG true
extern vector<parsetree*> pts;
int extend = 0;
vector<string> stdlibs(){
	return vector<string>{"OutputStream","PrintStream","Serializable","Byte","Character","Class","Cloneable","Integer","Number","Object","Short","String","System","Arrays"};
}
vector<string> primitivetype(){
	return vector<string>{"INT", "CHAR", "SHORT","BYTE","BOOLEAN"};
}
extern vector<parsetree*> stdlibpts;
void link_type(parsetree* pt)
{
	//Check whether the importondemand exists
	for(int i =0 ; i < pt->getscope()->ondemandimports.size(); i++)
	{
		int found = 0;
		for(int j = 0 ; j < pts.size() ; j++)
		{
			if(pts.at(j)->getscope()->package!= NULL)
			{
				if(packagematch(pt->getscope()->ondemandimports.at(i)->at(1),pts.at(j)->getscope()->package->at(1)))
				{
					found = 1;
				}
			}
		}
		if(found == 0)
		{
		if(DEBUG) cerr << "On demand imports is not found." << endl;
			exit(42);
		}
	}
	//check whehter the package can be resolved to a type.
	parsetree* package = pt->getscope()->package;
	if(package != NULL)
	{
		if(package->at(1)->getname() == "QualifiedName")
		{
			package = package->at(1);
			for(int i = 0 ; i < pts.size();i++)
			{
				if(pts.at(i)->getscope()->package != NULL)
				{
					string classname = scopetoclass_interfacename(pts.at(i)->getscope());
					parsetree* package1 = pts.at(i)->getscope()->package;
					if(package_clash_withtype(package1, package, classname))
					{
						if(DEBUG) cerr << "Package or prefix of package can be resolve to a type." << endl;
							exit(42);
					}
				}
			}
		}
	}
	scope* sc = pt->getscope();
	//check whether the prefix of single import can be resolved to a type
	for(int i =0 ;i < sc->singleimports.size();i++)
	{
		int found1 = 0;
		string classname1 = sc->singleimports.at(i)->at(1)->at(2)->getlexeme();
		for(int j = 0 ;j < pts.size() ;j++)
		{
			parsetree* type = sc->singleimports.at(i)->at(1)->at(0);
			parsetree* package = pts.at(j)->getscope()->package;
			string classname = scopetoclass_interfacename(pts.at(j)->getscope());
			if(package != NULL && type ->getname() == "QualifiedName")
			{
				if(package_clash_withtype(package, type, classname))
				{
					if(DEBUG) cerr << "Prefix of single import can be resolve to a type." << endl;
						exit(42);
				}
			}
			if(package != NULL &&samepackage(package->at(1), type) && classname1 == classname)
			{
				found1 = 1;
			}
		}
		if(found1 == 0)
		{
			if(DEBUG) cerr << "ALL SINGLE IMPORT SHOULD BE RESOLVED TO A TYPE." << endl;
				exit(42);
		}
	}
	stack<parsetree*> mystack;
	mystack.push(pt);
	parsetree* now = pt;
	while(mystack.size() != 0)
	{
		now = mystack.top();
		mystack.pop();
		string name = now->getname();
		if(name == "Type")
		{
			parsetree* type_node = now->at(0);
			link_type_node(type_node);
		}
		else if(name == "Super")
		{
			extend = 1;
			link_type_node(now->at(1));
			extend = 0;
			parsetree* temp = now->at(1);
			parsetree* l = temp;
			if(temp->getname() == "ID")
				l = temp;
			else if(temp->getname() == "QualifiedName")
				l = temp->at(2);
			if(l->link->getname() != "ClassDeclaration")
			{
				if(DEBUG) cerr<< "A class must not extend an interface." << endl;
				exit(42);
			}
			if(is_member("final", get_all_terminals_in_pt(l->link->at(0))))
			{
				if(DEBUG) cerr<< "A class must not extend a final class" << endl;
				exit(42);
			}
		}
		else if(name == "Interfaces")
		{
			link_type_interface(now->at(1));
		}
		else if(name == "ExtendsInterfaces")
		{
			link_extend_interface(now);
		}
		else if(name == "ClassInstanceCreationExpression")
		{
			link_type_node(now->at(1));
		}
		else
		{
			for(int i =0 ;i < now->size(); i++)
			{
				mystack.push(now->at(i));
			}
		}
	}
}

void link_type_node(parsetree* type_node)
{
	//May have Array type, QualifiedName type, simple ID type, or primitive type.
	if(type_node->getname() == "QualifiedName")
	{
		parsetree* packagetree = type_node->at(0);
		string cname = type_node->at(2)->getlexeme();
		string parentname = type_node->getparent()->getname();
		vector<string> extendnames{"Super","ExtendsInterfaces","InterfaceTypeList"};
		if(cname == packagetree->getlexeme())
		{
			if(!is_member(parentname, extendnames))
			{
			if(DEBUG) cerr<< "PACKAGE CLASH WITH CLASSNAME" << endl;
				exit(42);
			}
		}
		int check_resolve_default_package = 0;
		parsetree* first_package = packagetree;
		string first_package_lex;
		scope* sp = type_node->getscope();
		while(sp->getname() != "CompilationUnit")
			sp = sp->getparent();
		while(first_package->getname() != "ID")
			first_package = first_package->at(0);
		first_package_lex = first_package->getlexeme();
		if(sp->package == NULL)
			check_resolve_default_package = 1;
		int found = 0;
		for(int i =0 ;i < pts.size(); i++)
		{
			if(pts.at(i)->getscope()->package != NULL)
			{
				if(package_clash_withtype(pts.at(i)->getscope()->package, packagetree, scopetoclass_interfacename(pts.at(i)->getscope())))
				{
					if(DEBUG) cerr << "Package clash with type explicitly" << endl;
						exit(42);
				}
				if(samepackage(packagetree, pts.at(i)->getscope()->package->at(1)))
				{
					if(pts.at(i)->getscope()->classes.size() != 0 && cname == classname(pts.at(i)->getscope()->classes.at(0)))
					{
						type_node->at(2)->link = pts.at(i)->getscope()->classes.at(0);
						found = 1;
					}
					if(pts.at(i)->getscope()->interfaces.size() != 0 && cname == interfacename(pts.at(i)->getscope()->interfaces.at(0)))
					{
						type_node->at(2)->link = pts.at(i)->getscope()->interfaces.at(0);
						found = 1;
					}
				}
			}
			else
			{
				if(check_resolve_default_package)
				{
					if(scopetoclass_interfacename(pts.at(i)->getscope()) == first_package_lex)
					{
						if(DEBUG) cerr << "Resolve Default package." << endl;
							exit(42);
					}
				}
			}
		}
		if(found)
			return;
		if(DEBUG) cerr << "Qualified Name Can Not Link to a Class." << endl;
			exit(42);
	}
	else if(type_node->getname() == "ID")
	{
		link_class(type_node);
		// parsetree* link = type_node->link;
		// if(link->getscope()->getparent()->package != NULL && classname(link) == link->getscope()->getparent()->package->at(1)->getlexeme())
		// {
			// if(DEBUG) cerr << "No Prefix of Package name can be resolved to a type." << endl;
				// exit(42);
		// }
	}
	else if(type_node->getname() == "ArrayType")
	{
		link_type_node(type_node->at(0));
	}
	else			//Primitivetype
	{
	
	}
}

void link_class(parsetree* pt)
{
	string name = pt->getlexeme();
	scope* s = pt->getscope();
	while(s->getname() != "CompilationUnit")
	{
		s = s->getparent();
	}
	if(s->classes.size() != 0)
	{
		if(classname(s->classes.at(0)) == name)
		{
			pt->link = s->classes.at(0);
			if(s->package != NULL && s->package->at(1)->getlexeme() == name)
			{
				for(int i = 0; i< s->singleimports.size(); i++)
				{
					if(singleimportclassname(s->singleimports.at(i)) == name)
						return;
				}
				for(int i =0; i < s->ondemandimports.size(); i++)
				{
					vector<parsetree*> matches = matchclasses_ondemand(s->ondemandimports.at(i), name);
					if(matches.size() == 1)
						return;
				}
				if(DEBUG) cerr << "RESOLVE PACKAGE NAME CLASH WITH TYPE NAME" << endl;
				exit(42);
			}
			return;
		}
	}
	if(s->interfaces.size() != 0)
	{
		if(interfacename(s->interfaces.at(0)) == name)
		{
			pt->link = s->interfaces.at(0);
			if(s->package != NULL && s->package->at(1)->getlexeme() == name)
			{
				for(int i = 0; i< s->singleimports.size(); i++)
				{
					if(singleimportclassname(s->singleimports.at(i)) == name)
						return;
				}
				for(int i =0; i < s->ondemandimports.size(); i++)
				{
					vector<parsetree*> matches = matchclasses_ondemand(s->ondemandimports.at(i), name);
					if(matches.size() == 1)
						return;
				}
				if(DEBUG) cerr << "RESOLVE PACKAGE NAME CLASH WITH TYPE NAME" << endl;
				exit(42);
			}
			return;
		}
	}
	for(int i =0 ; i < s->singleimports.size(); i++)	//link to single imports
	{
		if(s->singleimports.at(i)->at("QualifiedName")->at(2)->getlexeme() == name)
		{
			parsetree* importclass = singleimporttoclass(s->singleimports.at(i));
			pt->link = importclass;
			return;
		}
	}
	if(!is_member(scopetoclass_interfacename(s), stdlibs()) && name == "Serializable")
	{
		if(DEBUG) cerr << "Implement serializable" << endl;
		exit(42);
	}
	if(s->package != NULL)			//link to the same package
	{
		for(int i =0 ;i < pts.size(); i++)
		{
			if(pts.at(i)->getscope()->package != NULL)
			{
				if(samepackage(s->package, pts.at(i)->getscope()->package))
				{
					if(pts.at(i)->getscope()->classes.size() != 0 && name == classname(pts.at(i)->getscope()->classes.at(0)))
					{
						pt->link = pts.at(i)->getscope()->classes.at(0);
						return;
					}
					if(pts.at(i)->getscope()->interfaces.size() != 0 && name == interfacename(pts.at(i)->getscope()->interfaces.at(0)))
					{
						pt->link = pts.at(i)->getscope()->interfaces.at(0);
						return;
					}
				}
			}
		}
	}
	else
	{
		for(int i =0 ; i < pts.size(); i++)
		{
			if(pts.at(i)->getscope()->package == NULL)
			{
				if(name == scopetoclass_interfacename(pts.at(i)->getscope()))
				{
					if(pts.at(i)->getscope()->classes.size() != 0)
					{
						pt->link = pts.at(i)->getscope()->classes.at(0);
						return;
					}
					else
					{
						pt->link = pts.at(i)->getscope()->interfaces.at(0);
						return;
					}
				}
			}
		}
	}
	int foundinondemandimports = 0;
	for(int i =0 ;i < s->ondemandimports.size(); i++)
	{
		vector<parsetree*> matchclasses = matchclasses_ondemand(s->ondemandimports.at(i),name);
		if(matchclasses.size() == 1)
		{
			if(foundinondemandimports == 0)
			{
				pt->link = matchclasses.at(0);
				foundinondemandimports = 1;
			}
			else
			{
				if(pt->link != matchclasses.at(0))
				{
					if(DEBUG) cerr<< "Clash with Implicit imports" << endl;
						exit(42);
				}
			}
		}
		else if(matchclasses.size() > 1)
		{
			if(DEBUG) cerr << "More than 1 Match classes or interfaces from on demand imports" << endl;
			exit(42);
		}
	}
	for(int i =0 ;i < stdlibpts.size(); i++)
	{
		if(stdlibpts.at(i)->getscope()->classes.size() != 0 && classname(stdlibpts.at(i)->getscope()->classes.at(0)) == name)
		{
			if(foundinondemandimports)
			{
				if(pt->link != stdlibpts.at(i)->getscope()->classes.at(0))
				{
					if(DEBUG) cerr<< "Clash with Implicit imports" << endl;
					exit(42);
				}
			}
			pt->link = stdlibpts.at(i)->getscope()->classes.at(0);
			return;
		}
		if(stdlibpts.at(i)->getscope()->interfaces.size() != 0 && interfacename(stdlibpts.at(i)->getscope()->interfaces.at(0)) == name)
		{
			if(foundinondemandimports)
			{
				if(pt->link != stdlibpts.at(i)->getscope()->interfaces.at(0))
				{
					if(DEBUG) cerr<< "Clash with Implicit imports" << endl;
					exit(42);
				}
			}
			pt->link = stdlibpts.at(i)->getscope()->interfaces.at(0);
			return;
		}
	}
	if(foundinondemandimports)
		return;
	if(DEBUG) cerr << "Can Not Link to a Class." << endl;
	exit(42);
}

void link_type_interface(parsetree* pt)
{
	parsetree* temp = pt;
	vector<parsetree*> interfaces;
	while(temp->getname() == "InterfaceTypeList")
	{
		if(temp->size() == 3)
		{
			extend = 1;
			link_type_node(temp->at(2));
			extend = 0;
			parsetree* l = temp->at(2);
			if(l->getname() == "ID")
			{
				l = l;
				// if(!is_member(scopetoclass_interfacename(pt->getscope()->getparent()), stdlibs()) && interfacename(l->link) == "Serializable")
				// {
					// if(DEBUG) cerr << "Implement serializable" << endl;
					// exit(42);
				// }
			}
			else if(l->getname() == "QualifiedName")
				l = l->at(2);
			else if(l->getname() == "ArrayType")
				l = l->at(0);
			if(l->link->getname()!= "InterfaceDeclaration")
			{
				if(DEBUG) cerr<< "A class must not implement a class."<<endl;
				exit(42);
			}
			if(is_member(l->link, interfaces))
			{
				if(DEBUG) cerr<< "An interface must not be repeated in an implements clause, or in an extends clause of an interface."<<endl;
				exit(42);
			}
			interfaces.push_back(l->link);
		}
		else
		{
			extend = 1;
			link_type_node(temp->at(0));
			extend = 0;
			parsetree* l = temp->at(0);
			if(l->getname() == "ID")
			{
				// if(!is_member(scopetoclass_interfacename(pt->getscope()->getparent()), stdlibs()) && interfacename(l->link) == "Serializable")
				// {
					// if(DEBUG) cerr << "Implement serializable" << endl;
					// exit(42);
				// }
			}
			else if(l->getname() == "QualifiedName")
				l = l->at(2);
			else if(l->getname() == "ArrayType")
				l = l->at(0);
			if(l->link->getname()!= "InterfaceDeclaration")
			{
				if(DEBUG) cerr<< "A class must not implement a class."<<endl;
				exit(42);
			}
			if(is_member(l->link, interfaces))
			{
				if(DEBUG) cerr<< "An interface must not be repeated in an implements clause, or in an extends clause of an interface."<<endl;
				exit(42);
			}
			break;
		}
		temp = temp->at(0);
	}
}

void link_extend_interface(parsetree* pt)
{
	parsetree* temp = pt;
	vector<parsetree*> interfaces;
	while(temp->getname() == "ExtendsInterfaces")
	{
		if(temp->size() == 3)
		{
			extend = 1;
			link_type_node(temp->at(2));
			extend = 0;
			parsetree* l = temp->at(2);
			if(l->getname() == "QualifiedName")
				l = l->at(2);
			else if(l->getname() == "ArrayType")
				l = l->at(0);
			if(l->link->getname() != "InterfaceDeclaration")
			{
				if(DEBUG) cerr<< "An interface must not extend a class."<<endl;
				exit(42);
			}
			if(is_member(l->link, interfaces))
			{
				if(DEBUG) cerr<< "An interface must not be repeated in an implements clause, or in an extends clause of an interface."<<endl;
				exit(42);
			}
			interfaces.push_back(l->link);
		}
		else
		{
			extend = 1;
			link_type_node(temp->at(1));
			extend = 0;
			parsetree* l = temp->at(1);
			if(l->getname() == "QualifiedName")
				l = l->at(2);
			else if(l->getname() == "ArrayType")
				l = l->at(0);
			if(l->link->getname() != "InterfaceDeclaration")
			{
				if(DEBUG) cerr<< "An interface must not extend a class."<<endl;
				exit(42);
			}
			if(is_member(l->link, interfaces))
			{
				if(DEBUG) cerr<< "An interface must not be repeated in an implements clause, or in an extends clause of an interface."<<endl;
				exit(42);
			}
			interfaces.push_back(l->link);
			break;
		}
		temp = temp->at(0);
	}
}

int is_member(parsetree* pt, vector<parsetree*> interfaces)
{
	for(int i =0 ;i < interfaces.size(); i++)
	{
		if(pt== interfaces.at(i))
			return 1;
	}
	return 0;
}

int package_clash_withtype(parsetree* package1, parsetree* package2, string cname)
{
	if(package2->getname() == "ID")
		return 0;
	else
	{
		parsetree* temp1 = package1->at(1);
		parsetree* temp2 = package2;
		while(temp1->getname() == "QualifiedName")
			temp1 = temp1->at(0);
		while(temp2->getname() == "QualifiedName")
			temp2 = temp2->at(0);
		if(temp1->getlexeme() == temp2->getlexeme())
		{
			while(temp1 != package1->at(1))
			{
				temp1 = temp1->getparent();
				temp2 = temp2->getparent();
				if(temp2 == package2)
				{
					if(temp1 == package1->at(1) && temp2->at(2)->getlexeme() == cname)
						return 1;
					else
						return 0;
				}
				if(temp1->at(2)->getlexeme() != temp2->at(2)->getlexeme())
					return 0;
			}
			if(temp2->getparent()->at(2)->getlexeme() == cname)
				return 1;
		}
		else
		{
			return 0;
		}
	}	
	return 0;
}
//`find -L stdlib/ -name '*.java'`
package A;
public interface simple extends simple2,simple3{
}
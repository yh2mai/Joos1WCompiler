#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__

#include <string>
#include <stdlib.h>
#include <iostream>
#include <unordered_map>

using namespace std;

unordered_map<string,int>kind_priority_hash();

#endif
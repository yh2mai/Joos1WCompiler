#include "parsetree.h"
#include <iostream>
#include <vector>
#include "lr1.h"
#include "../scanner/token.h"
#include <algorithm>
#include <map>
#include <stack>
#include <assert.h>
#include <boost/lexical_cast.hpp>
#define DEBUG false

using namespace std;

parsetree::parsetree(string name1, string lexeme1)
{
	name = name1;
	lexeme = lexeme1;
}

parsetree::parsetree(ifstream *f)
{
	string line;
	getline(*f, line);
	vector<string> tokens = tokenize(line);
	name = tokens.at(0);
	lexeme = tokens.at(1);
	int size = boost::lexical_cast<int>(tokens.at(2));
	// cout << "children size = " << size << " name = " << name << " lexeme = " << lexeme << endl;
	for(int i = 0; i < size; i++)
	{
		parsetree *temp =new parsetree(f);
		children.push_back(temp);
	}
}

parsetree::parsetree(LR1 lr1,vector<struct exrule> * derivations, string start, vector<struct Token> *tokens){

	stack<parsetree*> mystacknode;
	struct exrule firstrule;
	parsetree* now = new parsetree(start,"");
	now->setparent(NULL);
	parsetree* nodep = new parsetree("","");
	//push root to the empty stack
	name = start;
	mystacknode.push(this);
	
	if(DEBUG) cout << "parse tree while loop start....." << endl;
	while(mystacknode.size()>0){
		//cout << "get top from stack" << endl;
		//peek and pop from stack
		now = mystacknode.top();
		
		//now->children = ttt;
		if(DEBUG)
		{
		cout << "now is " << now->name << endl;
		cout << "now has children size " << now->children.size() << endl; 
		cout << "delete top from stack" << endl;
		}
		mystacknode.pop();
		//assign env
		//if it is a terminal symbol
		if(isTerminalnew(now->name, lr1)){
			//cout << "is terminal..." << endl;
			if(start != "")
			{
				now->lexeme = tokens->at(tokens->size() - 1).lexeme;
				tokens->erase(tokens->end() - 1);
			}
			//name = start;
			//cout << "is terminal case end" << endl;
		}
		//non-terminal symbol
		else{
			//cout << "is not terminal..." << endl;
			//get the first derivation
			firstrule = derivations->at(derivations->size() - 1);
			//erase the first rule
			derivations->pop_back();
			//firstrule.print();
			//if no children
			if(firstrule.to.size() == 0){
				//cout << "no children" << endl;
				parsetree *temp= new parsetree("","");
				temp->name = "";
				now->children.push_back(temp);
				//nodep = now->children.at(0);
				//mystacknode.push(nodep);
				//cout << "no children case end" << endl;
			}
			//if it has children
			else{
				//cout << "has children case" << endl;
				
				for(int i = 0 ; i < firstrule.to.size(); i++)
				{
					parsetree* temp = new parsetree("","");
					temp->setparent(now);
					now->children.push_back(temp);
				}
				for(int i = 0; i<firstrule.to.size(); i++){
					//cout << "for loop time: " << i << endl;

					//cout << "step1" << endl;
					now->children.at(i)->name = firstrule.to.at(i);

					//cout << "step2" << endl;
					//cout << "now is " << now->name << endl;
					//cout << "now has children size " << now->children.size() << endl;
					//cout << "child " << i << " is " << now->children.at(i).name << endl;
					//cout << "child " << i << " has children size " << now->children.at(i).children.size() << endl;
					//cout << "step3" << endl;
					nodep = now->children.at(i);
					
					//cout << "step4" << endl;
					
					if(now==NULL){cout << "now become NULL!!" << endl;}
 
					//cout << "step5" << endl;
					mystacknode.push(nodep);
					//if(mystacknode.top()==nodep){
					//	cout << "pushed nodep correctly" << endl;
						
					//}
					//else {cout << "pushed nodep incorrectly!" << endl;}
				}
				//cout << "has children case end" << endl;
			}
		}

		//cout << "now is " << now->name << endl;
		//cout << "children size is " << now->children.size() << endl << endl;
	}
	if(DEBUG)cout << "end building" << endl;
}

void parsetree::addchild(parsetree *pt)
{
	children.push_back(pt);
}

string parsetree::getname()
{
	return name;
}

string parsetree::getlexeme()
{
	return lexeme;
}
vector<parsetree*> parsetree::getchildren()
{
	return children;
}
void parsetree::print(int indent)
{
	// cout << "children size is" << children.size() << endl;
	
	if(children.size() == 0)
	{
		// cout << "size is 0" << endl;
		printindent(indent);
		cout << "- " << name;
		if(name != "")
			cout <<"("<<lexeme<<")";
		cout << endl;
	}
	else
	{
		// cout << "size is not 0" << endl;
		printindent(indent);
		cout << "- " << name;
		cout << endl;
		// cout << "for loop" << endl;
		for(int i =0 ; i< children.size(); i++)
		{
			children.at(i)->print(indent + name.size() + 2);
		}
		// cout << "for loop ends" << endl;
	}
}

void parsetree::write(ofstream * o){
	*o << name << " " << lexeme << " " << children.size();
	*o << endl;
	for(int i = 0 ; i < children.size();i++)
	{
		children.at(i)->write(o);
	}
}
vector<string> tokenize(string line)
{
// cout << line << endl;
	vector<string> ret;
	string temp = line.substr(0,1);
	line = line.substr(1, line.length() - 1);
	bool s = false;
	while(line != "")
	{
		string first = line.substr(0,1);
		if(first == " "&& !s)
		{
			ret.push_back(temp);
			temp = "";
			if(line.substr(1,line.length() - 1) == "")
				return ret;
		}
		else
		{
			if(first == "\"" || first == "\'")
					s = !s;
			temp += first;
		}
		line = line.substr(1, line.length() - 1);
	}
	ret.push_back(temp);
	return ret;
}

int isTerminalnew(string symbol, LR1 lr1)
{
	
	if(symbol == "")
		return 1;

	map<string,int>::iterator f;
	f = lr1.terminals_hash.find(symbol);
	if (f != lr1.terminals_hash.end())
		return 1;
	
	return 0;
}

void printindent(int k){
	for(int i =0; i < k ;i++)
	cout << " ";
}

void parsetree::setparent(parsetree* p)
{
	parent = p;
}

int is_member(string a, vector<string> list) {
	for (int i = 0; i < list.size(); i++) {
		if (a == list.at(i)) {
			return 1;
		}
	}
	return 0;
}

vector<string> nodes_need_to_be_saved()
{
	string node_to_be_save [] = {"Modifier","Type","VariableDeclarator","Expression","FormalParameterList","ArgumentList"};
	vector<string> nodes_to_be_saved(node_to_be_save, node_to_be_save + sizeof(node_to_be_save)/sizeof(string));
	return nodes_to_be_saved;
}


parsetree * ast(parsetree *pt)			
{
	if(pt->getchildren().size () == 0)
	{
		return pt;
	}
	else if (pt->getchildren().size() == 1 && !is_member(pt->getname(), nodes_need_to_be_saved()))
	{
		parsetree* p = pt->getparent();
		parsetree* temp = ast(pt->at(0));
		temp->setparent(p);
		free(pt);
		return temp;
	}
	else
	{
		vector<parsetree*> children;
		for(int i =0; i< pt->getchildren().size() ; i++)
		{
			parsetree *temp = ast(pt->getchildren().at(i));
			if(temp->getname() == "")
			{
				free(temp);
				continue;
			}
			else
			{
				children.push_back(temp);
			}
		}
		pt->setchildren(children);
		return pt;
	}
}

void parsetree::setchildren(vector<parsetree*> c)
{
	children = c;
}

int parsetree::size(){
	return children.size();
}

parsetree* parsetree::at(int i)
{
	if(i>=children.size())
	{
		cerr<< "Parsetree does not have that many children " << endl;
		exit(42);
	}
	else
		return children.at(i);
}

parsetree* parsetree::getparent()
{
	return parent;
}

parsetree* parsetree::at(string s){
	for(int i =0 ; i < size(); i++)
	{
	if(at(i)->getname() == s)
		return at(i);
	}
	cerr<< "Parsetree does not have a child name " << s << endl;
	exit(42);
}

vector<string> get_all_terminals_in_pt(parsetree * pt)
{
	vector<string> ret;
	stack<parsetree*> mystack;
	mystack.push(pt);
	while(mystack.size() != 0)
	{
		parsetree* now = mystack.top();
		mystack.pop();
		if(now->getlexeme() != "")
		{
			ret.push_back(now->getlexeme());
		}
		for(int i =0 ;i < now->size(); i ++)
		{
			mystack.push(now->at(i));
		}	
	}
	return ret;
}

vector<string> get_all_terminalsname_in_pt(parsetree* pt)
{
	vector<string> ret;
	stack<parsetree*> mystack;
	mystack.push(pt);
	while(mystack.size() != 0)
	{
		parsetree* now = mystack.top();
		mystack.pop();
		if(now->getlexeme() != "")
		{
			ret.push_back(now->getname());
		}
		for(int i =0 ;i < now->size(); i ++)
		{
			mystack.push(now->at(i));
		}	
	}
	return ret;
}
//find all number and negative sign
vector<string> getnumber(parsetree *pt)
{
	vector<string> ret;
	if(pt->size() == 0)
	{
		if(pt->getname() == "DECIMALINTEGER")
		{
// cout << pt.getlexeme() << "  " << endl;
			ret.push_back(pt->getlexeme());
		}
		return ret;
	}
	else
	{
		if(pt->getname() == "UnaryExpression" && pt->at(0)->getname() == "MINUS" )
		{
			vector<string> terminals = get_all_terminalsname_in_pt(pt->at(1));
// cout << "FIRST CHILD  " << terminals.at(0) << endl;
			if(terminals.at(0) == "DECIMALINTEGER")
				ret.push_back("-");
			vector<string> temp = getnumber(pt->at(1));
			ret.insert(ret.end(), temp.begin(), temp.end());
			return ret;
		}
		for(int i =0 ; i < pt->size(); i ++)
		{
			vector<string> temp = getnumber(pt->at(i));
			ret.insert(ret.end(), temp.begin(), temp.end());
		}
	}
	return ret;
}
package A;
public interface b{
	public int m(int a, char b);
}
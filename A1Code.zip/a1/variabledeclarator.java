public class variabledeclarator{
	public int a;
}
#include "weeder.h"
#include <string>
#include <vector>
#include <stack>
#include <iostream>
#define DEBUG true
int weeder(parsetree * pt)
{
	string n = pt->getname();
	if(n == "ClassDeclaration")
	{
		if(weeder_classdeclaration(pt))
			return 1;
		else
			return weeder(pt->at("ClassBody"));
	}
	else if(n == "MethodDeclaration")
	{
		return weeder_methoddecl(pt);
	}
	else if(n == "VOID")
	{
		if(DEBUG) cerr << "The type void may only be used as the return type of a method." << endl;
		return 1;
	}
	else if(n == "AbstractMethodDeclaration")
	{
		return weeder_abstractmethoddecl(pt);
	}
	else if(n == "FieldDeclaration")
	{
		return weeder_fielddecl(pt);
	}
	else if(n == "CastExpression")
	{
		return weeder_cast(pt);
	}
	for(int i =0 ; i < pt->size() ; i++)
	{
		int ret = weeder(pt->at(i));
		if(ret)
			return ret;
	}
	return 0;	
}

int weeder_classdeclaration(parsetree * pt)
{
	parsetree* modifiers_pt = pt->at(0);
	if(pt->at(0)->getname() != "Modifier" && pt->at(0)->getname() != "Modifiers")
	{
		if(DEBUG) cerr << "Class has no modifiers" << endl;
				return 1;
	}
	vector<string> all_mods = get_all_terminals_in_pt(modifiers_pt);
	if(is_member("final", all_mods) && is_member("abstract", all_mods))
	{
	if(DEBUG) cerr << "A CLASS CONTAINS BOTH FINAL AND ABSTRACT !" << endl;
		return 1;
	}
	if(pt->at("ClassBody")->size() == 3)
	{
		if(pt->at("ClassBody")->at(1)->getname() != "ClassBodyDeclarations")
		{
			if(pt->at("ClassBody")->at(1)->getname() != "ConstructorDeclaration")
			{
			if(DEBUG) cerr << "Every class must contain at least one explicit constructor." << endl;
				return 1;
			}
		}
		else
		{
			vector<string> classbody;
			parsetree* classbodytree = pt->at("ClassBody")->at("ClassBodyDeclarations");
			while(classbodytree->getname() == "ClassBodyDeclarations")
			{
				classbody.push_back(classbodytree->at(1)->getname());
				classbodytree = classbodytree->at(0);
			}
			classbody.push_back(classbodytree->getname());
			if(!is_member("ConstructorDeclaration", classbody))
			{
			if(DEBUG) cerr << "Every class must contain at least one explicit constructor." << endl;
				return 1;
			}
		}
	}
	else
	{
	if(DEBUG) cerr << "Every class must contain at least one explicit constructor." << endl;
		return 1;
	}
	return 0;
}

int in_interface(parsetree* pt)
{
	parsetree* temp = pt;
	while(temp!= NULL)
	{
		if(temp->getname() == "InterfaceDeclaration")
			return 1;
		else
			temp = temp->getparent();
	}
	return 0;
}
int weeder_methoddecl(parsetree * pt)
{
	if(pt->at(0)->at(0)->getname() != "Modifier" && pt->at(0)->at(0)->getname() != "Modifiers")
	{
		if(DEBUG) cerr << "Method has no modifiers" << endl;
				return 1;
	}
	vector<string> all_mods = get_all_terminals_in_pt(pt->at(0)->at(0));
	if(!is_member("abstract",all_mods) && !is_member("native",all_mods))
	{
		if(pt->at(1)->getname() != "Block")
		{
		if(DEBUG) cerr<< "A method has a body if and only if it is neither abstract nor native." << endl;
			return 1;
		}
	}
	if(is_member("abstract",all_mods))
	{
		if(is_member("static",all_mods) || is_member("final",all_mods))
		{
		if(DEBUG) cerr<< "An abstract method cannot be static or final." << endl;
			return 1;
		}
		if(pt->at(1)->getname() == "Block")
		{
		if(DEBUG) cerr<< "An abstract method must not have a body" << endl;
			return 1;
		}
	}
	if(is_member("static",all_mods) && is_member("final",all_mods))
	{
		if(DEBUG) cerr<< "A static method cannot be final." << endl;
		return 1;
	}
	if(is_member("native",all_mods) && !is_member("static",all_mods))
	{
		if(DEBUG) cerr<< "A native method must be static." << endl;
		return 1;
	}
	if(!is_member("public",all_mods) && !is_member("protected",all_mods))
	{
		if(DEBUG) cerr<< "private method is not allowed" << endl;
		return 1;
	}
	return weeder(pt->at(1));
}

int weeder_name(parsetree* pt, string filename)
{
	string classname;
	if(pt->at(pt->size() - 1)->getname() == "ClassDeclaration")
		classname = pt->at("ClassDeclaration")->at("ID")->getlexeme();
	else
		classname = pt->at("InterfaceDeclaration")->at("ID")->getlexeme();
	if(filename != classname)
	{
		if(DEBUG) cerr<< "A class/interface must be declared in a .java file with the same base name as the class/interface." << endl;
		return 1;
	}
	return 0;
}

int weeder_abstractmethoddecl(parsetree* pt){
	vector<string> all_mods = get_all_terminals_in_pt(pt->at(0)->at(0));
	if(is_member("static",all_mods) || is_member("final",all_mods) || is_member("native",all_mods))
	{
		if(DEBUG) cerr<< "An interface method cannot be static, final, or native" << endl;
		return 1;
	}
	return 0;
}

int weeder_fielddecl(parsetree* pt)
{
	if(pt->at(0)->getname() != "Modifier" && pt->at(0)->getname() != "Modifiers")
	{
		if(DEBUG) cerr << "No Private field is allowed" << endl;
				return 1;
	}
	vector<string> all_mods = get_all_terminals_in_pt(pt->at(0));
	if(is_member("final",all_mods))
	{
		if(DEBUG) cerr<< "No field can be final." << endl;
		return 1;
	}
	if(!is_member("public",all_mods) && !is_member("protected",all_mods))
	{
		if(DEBUG) cerr << "No Private field is allowed" << endl;
				return 1;
	}
	return 0;
}

int weeder_cast(parsetree* pt)
{
	if(pt->at(1)->getname() == "Expression" && pt->at(1)->at(0)->getname() == "PrimaryNoNewArray" && pt->at(1)->at(0)->at(0)->getname() == "ROUNDBRACKET_L")
	{
	if(DEBUG) cerr<< "Cast_DoubleParenthese" << endl;
		return 1;
	}
	if(pt->at(1)->getname() == "Expression" && pt->at(1)->at(0)->getname() == "AdditiveExpression")
	{
	if(DEBUG) cerr<< " cast to an expression is not allowed" << endl;
		return 1;
	}
	if(pt->at(1)->getname() == "Expression" && pt->at(1)->at(0)->getname() == "FieldAccess")
	{
	if(DEBUG) cerr<< " cast to a nonstatic field is not allowed " << endl;
		return 1;
	}
	if(pt->at(1)->getname() == "Expression" && pt->at(1)->at(0)->getname() == "ArrayAccess")
	{
	if(DEBUG) cerr<< " CastToArrayLvalue is not allowed " << endl;
		return 1;
	}
	if(pt->at(1)->getname() == "Expression" && pt->at(1)->at(0)->getname() == "MethodInvocation")
	{
	if(DEBUG) cerr<< "Method invocation not allowed as type in cast. " << endl;
		return 1;
	}
	return weeder(pt->at(1)) && weeder(pt->at(3));
}

int inRange(vector<string> numbers)
{
	int neg = 0;
	int in = 1;
	for(int i = 0; i < numbers.size() ; i++)
	{
// cout << "numbers.at(i) == " << numbers.at(i) << endl;
		if(numbers.at(i) == "-")
		{
			neg = 1;
			continue;
		}
		else if(numbers.at(i).length() >10)
		{
			return 0;
		}
		else if (numbers.at(i).length() < 10)
		{
			continue;
		}
		else
		{
			string number = numbers.at(i);
			if(number.at(0) > '2')
				in = 0;
				else if (number.substr(0, 1) == "2" && number.at(1) > '1')
					in = 0;
						else if (number.substr(0,2) == "21" && number.at(2) > '4')
							in = 0;
							else if (number.substr(0, 3) == "214" && number.at(3) > '7')
								in = 0;
								else if (number.substr(0,4) == "2147" && number.at(4) > '4')
									in = 0;
									else if (number.substr(0,5) == "21474" && number.at(5) > '8')
										in = 0;
										else if (number.substr(0, 6) == "214748" && number.at(6) > '3')
										in = 0;
											else if (number.substr(0,7) == "2147483" && number.at(7) > '6')
												in = 0;
												else if (number.substr(0,8) == "21474836" && number.at(8) > '4')
													in = 0;
													else
													{
														if(neg)
														{
															if(number.substr(0, 9) == "214748364" && number.at(9) > '8')
															{
																in = 0;
															}
															else
															{
																neg = 0;
																continue;
															}
														}
														else
														{
															if(number.at(9) > '7')
																in = 0;
														}
													}
			if(in == 0)
				return 0;
		}
	}
	return 1;
}